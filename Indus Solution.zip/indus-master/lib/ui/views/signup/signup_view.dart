import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:indus/ui/common/app_colors.dart';
import 'package:indus/ui/widgets/common/top/top.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_strings.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/button_helper.dart';
import '../../common/uihelper/text_helper.dart';
import '../../common/uihelper/text_veiw_helper.dart';
import 'signup_viewmodel.dart';

class SignupView extends StackedView<SignupViewModel> {
  const SignupView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    SignupViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: white,
      body: SafeArea(
        child: Column(
          children: [
            Top(textdown: "Welcome! Please sign In"),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(15, 25, 15, 0),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          width: screenWidthCustom(context, 0.25),
                          height: screenWidthCustom(context, 0.25),
                          decoration: BoxDecoration(
                              color: white,
                              borderRadius: BorderRadius.circular(50),
                              border: Border.all(
                                  width: 3,
                                  color: kcPrimaryColorDark,
                                  strokeAlign: BorderSide.strokeAlignOutside)),
                          child: InkWell(
                            onTap: () => viewModel.pic(),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(50),
                              child: viewModel.image == null
                                  ? const Icon(
                                      Icons.person,
                                      size: 80,
                                    )
                                  : Image.file(
                                      viewModel.image!,
                                      fit: BoxFit.cover,
                                    ),
                            ),
                          ),
                        ),
                      )
                          .animate(delay: 500.milliseconds)
                          .fade()
                          .moveY(begin: 50, end: 0),
                      text_view_helper(
                        hint: "Enter name",
                        controller: viewModel.name,
                        showicon: true,
                        formatter: [
                          FilteringTextInputFormatter.allow(getRegExpstring())
                        ],
                      )
                          .animate(delay: 700.milliseconds)
                          .fade()
                          .moveY(begin: 50, end: 0),
                      text_view_helper(
                        hint: "Enter number",
                        controller: viewModel.number,
                        showicon: true,
                        icon: const Icon(Icons.call),
                        maxlength: 11,
                        formatter: [
                          FilteringTextInputFormatter.allow(getRegExpint())
                        ],
                        textInputType: TextInputType.phone,
                      )
                          .animate(delay: 900.milliseconds)
                          .fade()
                          .moveY(begin: 50, end: 0),
                      text_view_helper(
                        hint: "Enter cnic",
                        controller: viewModel.cnic,
                        showicon: true,
                        icon: const Icon(Icons.dock),
                        maxlength: 13,
                        formatter: [
                          FilteringTextInputFormatter.allow(getRegExpint())
                        ],
                        textInputType: TextInputType.phone,
                      )
                          .animate(delay: 1100.milliseconds)
                          .fade()
                          .moveY(begin: 50, end: 0),
                      text_view_helper(
                              hint: "Enter address",
                              controller: viewModel.address,
                              showicon: true,
                              icon: const Icon(Icons.home))
                          .animate(delay: 1300.milliseconds)
                          .fade()
                          .moveY(begin: 50, end: 0),
                      InkWell(
                        onTap: () => viewModel.selectdob(context),
                        child: Container(
                          width: screenWidth(context),
                          padding: const EdgeInsets.fromLTRB(10, 15, 10, 15),
                          decoration: BoxDecoration(
                              boxShadow: [
                                BoxShadow(
                                    offset: const Offset(2, 2),
                                    blurRadius: 1,
                                    spreadRadius: 1,
                                    color: getColorWithOpacity(
                                        kcPrimaryColorDark, 0.2))
                              ],
                              borderRadius: BorderRadius.circular(10),
                              color: white),
                          child: Row(
                            children: [
                              horizontalSpaceSmall,
                              const Icon(Icons.date_range),
                              horizontalSpaceSmall,
                              text_helper(
                                  data: viewModel.dob.text == ''
                                      ? "Select Date of Birth"
                                      : viewModel.dob.text,
                                  font: poppins,
                                  color: viewModel.dob.text == ''
                                      ? kcDarkGreyColor
                                      : kcPrimaryColor,
                                  size: fontSize14),
                            ],
                          ),
                        ),
                      )
                          .animate(delay: 1500.milliseconds)
                          .fade()
                          .moveY(begin: 50, end: 0)
                    ],
                  ),
                ),
              ),
            ),
            button_helper(
                    onpress: () => viewModel.next(context),
                    color: kcPrimaryColorDark,
                    width: screenWidthCustom(context, 0.3),
                    child: text_helper(
                        data: "next",
                        font: poppins,
                        color: white,
                        bold: true,
                        size: fontSize14))
                .animate(delay: 1700.milliseconds)
                .fade()
                .moveY(begin: 50, end: 0),
            InkWell(
              onTap: () => viewModel.login(),
              child: text_helper(
                data: "Already have Account",
                font: poppins,
                color: kcDarkGreyColor,
                size: fontSize12,
              ),
            ).animate(delay: 1900.milliseconds).fade().moveY(begin: 50, end: 0),
            verticalSpaceMedium,
          ],
        ),
      ),
    );
  }

  @override
  SignupViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      SignupViewModel();
}
