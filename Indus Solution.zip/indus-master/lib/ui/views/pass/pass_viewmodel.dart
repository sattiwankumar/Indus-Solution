import 'package:fancy_password_field/fancy_password_field.dart';
import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../services/fire_service.dart';
import '../../../services/sharedpref_service.dart';
import '../../common/apihelpers/apihelper.dart';
import '../../common/uihelper/snakbar_helper.dart';
import '../login/login_view.dart';

class PassViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final _sharedpref = locator<SharedprefService>();
  final _fireService = locator<FireService>();

  TextEditingController pass = TextEditingController();
  FancyPasswordController passv = FancyPasswordController();
  TextEditingController conpass = TextEditingController();

  void next(BuildContext context) {
    if (pass.text.isEmpty || conpass.text.isEmpty) {
      show_snackbar(context, "fill all fields");
    } else if (!passv.areAllRulesValidated) {
      show_snackbar(context, "password is not strong");
    } else if (pass.text != conpass.text) {
      show_snackbar(context, "pass and confirm pass do not match");
    } else {
      displayprogress(context);
      Future<bool> result = _fireService.messaging.getToken().then((value) {
        _sharedpref.setString('deviceid', value.toString());
        return ApiHelper.registration(
          _sharedpref.readString('name'),
          _sharedpref.readString('cnic'),
          _sharedpref.readString('number'),
          _sharedpref.readString('address'),
          _sharedpref.readString('dob'),
          pass.text,
          value.toString(),
          _sharedpref.readString('img'),
          context,
        );
      });
      result.then((value) async {
        await ApiHelper.registerwallet(
            _sharedpref.readString('number'), context);
        if (value) {
          hideprogress(context);
          _navigationService.clearStackAndShow(Routes.loginView);
          _navigationService.replaceWithTransition(const LoginView(),
              routeName: Routes.loginView,
              transitionStyle: Transition.rightToLeft);
        } else {
          hideprogress(context);
          show_snackbar(context, 'try again later');
        }
      });
    }
  }
}
