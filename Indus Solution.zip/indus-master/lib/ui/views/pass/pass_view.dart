import 'package:fancy_password_field/fancy_password_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:indus/ui/common/app_colors.dart';
import 'package:indus/ui/widgets/common/top/top.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_strings.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/button_helper.dart';
import '../../common/uihelper/text_helper.dart';
import '../../common/uihelper/text_veiw_helper.dart';
import 'pass_viewmodel.dart';

class PassView extends StackedView<PassViewModel> {
  const PassView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    PassViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: Column(
            children: [
              Top(textdown: "Enter password to continue"),
              Expanded(
                  child: Padding(
                padding: const EdgeInsets.fromLTRB(15, 25, 15, 0),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Container(
                        width: screenHeightCustom(context, 1),
                        margin: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                  offset: const Offset(2, 2),
                                  blurRadius: 1,
                                  spreadRadius: 1,
                                  color: getColorWithOpacity(
                                      kcPrimaryColorDark, 0.2))
                            ],
                            borderRadius: BorderRadius.circular(10),
                            color: white),
                        child: FancyPasswordField(
                          passwordController: viewModel.passv,
                          controller: viewModel.pass,
                          style: text_helper.customstyle(poppins,
                              kcDarkGreyColor, fontSize14, context, false),
                          decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: "Enter Password",
                              hintStyle: text_helper.customstyle(poppins,
                                  kcDarkGreyColor, fontSize14, context, false),
                              prefixIcon: const Icon(Icons.password)),
                          validationRules: {
                            DigitValidationRule(),
                            UppercaseValidationRule(),
                            LowercaseValidationRule(),
                            SpecialCharacterValidationRule(),
                            MinCharactersValidationRule(6),
                          },
                          validationRuleBuilder: (rules, value) {
                            if (value.isEmpty) {
                              return const SizedBox.shrink();
                            }
                            return ListView(
                              shrinkWrap: true,
                              children: rules
                                  .map(
                                    (rule) => rule.validate(value)
                                        ? Row(
                                            children: [
                                              const Icon(
                                                Icons.check,
                                                color: Colors.green,
                                              ),
                                              const SizedBox(width: 12),
                                              text_helper(
                                                  data: rule.name,
                                                  font: poppins,
                                                  color: Colors.green,
                                                  size: fontSize12),
                                            ],
                                          )
                                        : Row(
                                            children: [
                                              const Icon(
                                                Icons.close,
                                                color: Colors.red,
                                              ),
                                              const SizedBox(width: 12),
                                              text_helper(
                                                  data: rule.name,
                                                  font: poppins,
                                                  color: Colors.red,
                                                  size: fontSize12),
                                            ],
                                          ),
                                  )
                                  .toList(),
                            );
                          },
                        )
                            .animate(delay: 700.milliseconds)
                            .fade()
                            .moveY(begin: 50, end: 0),
                      ),
                      text_view_helper(
                        hint: "ConfirmPassword",
                        controller: viewModel.conpass,
                        showicon: true,
                        obsecure: true,
                        icon: const Icon(Icons.password),
                      )
                          .animate(delay: 900.milliseconds)
                          .fade()
                          .moveY(begin: 50, end: 0),
                    ],
                  ),
                ),
              )),
              button_helper(
                      onpress: () => viewModel.next(context),
                      color: kcPrimaryColorDark,
                      width: screenWidthCustom(context, 0.5),
                      padding: const EdgeInsetsDirectional.all(8),
                      child: text_helper(
                        data: "Sign Up",
                        font: poppins,
                        color: white,
                        size: fontSize18,
                        bold: true,
                      ))
                  .animate(delay: 1100.milliseconds)
                  .fade()
                  .moveY(begin: 50, end: 0),
              verticalSpaceMedium
            ],
          ),
        ));
  }

  @override
  PassViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      PassViewModel();
}
