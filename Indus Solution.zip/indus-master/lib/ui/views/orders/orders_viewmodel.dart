import 'package:flutter/cupertino.dart';
import 'package:indus/ui/common/apihelpers/apihelper.dart';
import 'package:indus/ui/common/uihelper/snakbar_helper.dart';
import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../services/sharedpref_service.dart';

class OrdersViewModel extends BaseViewModel {
  final sharedpref = locator<SharedprefService>();

  String filter = '';

  Future<void> inprogresstoend(
      BuildContext context, String number, String idd) async {
    print(idd);
    bool c = await ApiHelper.updatestatus(number, "end", idd, context);
    if (c) {
      bool f = await ApiHelper.updatemechanics(idd, 'free', context);
    }
  }

  Future<void> reject(BuildContext context, String number) async {
    await ApiHelper.updatestatus(number, "reject", "", context);
    Navigator.pop(context);
  }

  Future<void> aspectnew(BuildContext context, String number) async {
    String id = '';
    for (var element in newmechanics) {
      if (element['name'] == ms) {
        id = element['_id'];
      }
    }
    if (id != '') {
      bool c = await ApiHelper.updatestatus(number, "in progress", id, context);
      if (c) {
        bool f = await ApiHelper.updatemechanics(id, 'not free', context);
      }
    } else {
      show_snackbar(context, "Select a rider");
    }
  }

  String ms = '';
  bool c = true;
  List<String> m = [];
  List newmechanics = [];
  void mechanics(List l) {
    if (c) {
      newmechanics = l;
      for (var element in l) {
        if (element['status'] == 'free') {
          m.add(element['name']);
        }
      }
      if (m.isNotEmpty) {
        ms = m[0];
      } else {
        m.add('');
        ms = '';
      }
      c = false;
    }
  }
}
