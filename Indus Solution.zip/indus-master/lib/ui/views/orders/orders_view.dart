import 'package:cached_network_image/cached_network_image.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:indus/ui/common/app_colors.dart';
import 'package:indus/ui/common/app_strings.dart';
import 'package:indus/ui/common/ui_helpers.dart';
import 'package:indus/ui/common/uihelper/button_helper.dart';
import 'package:indus/ui/common/uihelper/text_helper.dart';
import 'package:indus/ui/widgets/common/top2/top2.dart';
import 'package:stacked/stacked.dart';

import '../../common/apihelpers/apihelper.dart';
import '../../common/uihelper/snakbar_helper.dart';
import 'orders_viewmodel.dart';

class OrdersView extends StackedView<OrdersViewModel> {
  OrdersView({Key? key, required this.check}) : super(key: key);
  // false == admin || true == user
  bool check;

  @override
  Widget builder(
    BuildContext context,
    OrdersViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: Column(
            children: [
              Top2(txt: "Orders"),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    topview(viewModel, 'new'),
                    topview(viewModel, 'in progress'),
                    topview(viewModel, 'reject'),
                    topview(viewModel, 'end'),
                  ],
                ),
              ),
              Expanded(
                child: FutureBuilder(
                  future: check
                      ? ApiHelper.getorderbynum(
                          viewModel.sharedpref.readString('number'))
                      : ApiHelper.getorder(),
                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                    if (snapshot.hasData) {
                      return ListView.builder(
                        itemCount: snapshot.data.length,
                        itemBuilder: (BuildContext context, int index) {
                          if (viewModel.filter == '') {
                            return listdata(
                                context, snapshot, index, viewModel);
                          } else if (viewModel.filter ==
                              snapshot.data[index]['status']) {
                            return listdata(
                                context, snapshot, index, viewModel);
                          } else {
                            return const SizedBox.shrink();
                          }
                        },
                      );
                    } else if (snapshot.hasError) {
                      return const Icon(
                        Icons.error,
                        color: kcDarkGreyColor,
                      );
                    } else {
                      return displaysimpleprogress(context);
                    }
                  },
                ),
              ),
            ],
          ),
        ));
  }

  Widget listdata(BuildContext context, AsyncSnapshot snapshot, int index,
      OrdersViewModel viewModel) {
    String locationString = snapshot.data[index]['loc'];
    RegExp regExp = RegExp(r'lat\s*:\s*([-\d.]+)\s*Lon\s*:\s*([-\d.]+)',
        caseSensitive: false);
    RegExpMatch? match = regExp.firstMatch(locationString);
    double latitude = double.parse(match!.group(1)!);
    double longitude = double.parse(match.group(2)!);

    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: DottedBorder(
        borderType: BorderType.RRect,
        radius: const Radius.circular(10),
        dashPattern: const [8, 4],
        child: Column(
          children: [
            Container(
              width: screenWidth(context),
              padding: const EdgeInsets.all(10),
              margin: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: snapshot.data[index]['status'] == 'reject'
                      ? Colors.red
                      : snapshot.data[index]['status'] == 'end'
                          ? Colors.green
                          : kcPrimaryColorDark),
              child: Column(
                children: [
                  FutureBuilder(
                    future: ApiHelper.getoneuseronnumber(
                        snapshot.data[index]['number']),
                    builder: (BuildContext context, AsyncSnapshot snapshot) {
                      if (snapshot.hasData) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              text_helper(
                                  data: "User",
                                  font: poppins,
                                  color: white,
                                  size: fontSize16),
                              Row(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(500),
                                    child: CachedNetworkImage(
                                      imageUrl: snapshot.data['img'],
                                      imageBuilder: (context, imageProvider) =>
                                          Container(
                                        width: 50,
                                        height: 50,
                                        decoration: BoxDecoration(
                                          image: DecorationImage(
                                            image: imageProvider,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                      placeholder: (context, url) =>
                                          displaysimpleprogress(context),
                                      errorWidget: (context, url, error) =>
                                          const Icon(
                                        Icons.error,
                                        color: kcDarkGreyColor,
                                      ),
                                    ),
                                  ),
                                  horizontalSpaceSmall,
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      text_helper(
                                        data: snapshot.data['name'],
                                        font: poppins,
                                        color: white,
                                        size: fontSize14,
                                        bold: true,
                                      ),
                                      text_helper(
                                          data: snapshot.data['number'],
                                          font: poppins,
                                          color: white,
                                          size: fontSize14)
                                    ],
                                  )
                                ],
                              ),
                            ],
                          ),
                        );
                      } else if (snapshot.hasError) {
                        return const Icon(
                          Icons.error,
                          color: kcDarkGreyColor,
                        );
                      } else {
                        return displaysimpleprogress(context);
                      }
                    },
                  ),
                  verticalSpaceSmall,
                  snapshot.data[index]['mechanicsid'] == ""
                      ? const SizedBox.shrink()
                      : FutureBuilder(
                          future: ApiHelper.getmechanicsid(
                              snapshot.data[index]['mechanicsid']),
                          builder:
                              (BuildContext context, AsyncSnapshot snapshot) {
                            if (snapshot.hasData) {
                              return Container(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 10),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    text_helper(
                                        data: "Rider",
                                        font: poppins,
                                        color: white,
                                        size: fontSize16),
                                    Row(
                                      children: [
                                        ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(500),
                                          child: CachedNetworkImage(
                                            imageUrl: snapshot.data['profile'],
                                            imageBuilder:
                                                (context, imageProvider) =>
                                                    Container(
                                              width: 50,
                                              height: 50,
                                              decoration: BoxDecoration(
                                                image: DecorationImage(
                                                  image: imageProvider,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ),
                                            placeholder: (context, url) =>
                                                displaysimpleprogress(context),
                                            errorWidget:
                                                (context, url, error) =>
                                                    const Icon(
                                              Icons.error,
                                              color: kcDarkGreyColor,
                                            ),
                                          ),
                                        ),
                                        horizontalSpaceSmall,
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            text_helper(
                                              data: snapshot.data['name'],
                                              font: poppins,
                                              color: white,
                                              size: fontSize14,
                                              bold: true,
                                            ),
                                            text_helper(
                                                data: snapshot.data['number'],
                                                font: poppins,
                                                color: white,
                                                size: fontSize14)
                                          ],
                                        )
                                      ],
                                    ),
                                  ],
                                ),
                              );
                            } else if (snapshot.hasError) {
                              return const Icon(
                                Icons.error,
                                color: kcDarkGreyColor,
                              );
                            } else {
                              return displaysimpleprogress(context);
                            }
                          },
                        ),
                  snapshot.data[index]['type'].toString().split(" ")[0] ==
                              'mechanics' ||
                          snapshot.data[index]['type']
                                  .toString()
                                  .split(" ")[0] ==
                              'Electrician'
                      ? rowtext(Icons.deselect_sharp, "Description",
                          snapshot.data[index]['quantity'])
                      : rowtext(Icons.production_quantity_limits, "Quantity",
                          snapshot.data[index]['quantity']),
                  rowtext(Icons.not_listed_location_rounded, "location",
                      snapshot.data[index]['loc']),
                  rowtext(
                      Icons.merge_type, "type", snapshot.data[index]['type']),
                  rowtext(
                      Icons.description, "notes", snapshot.data[index]['des']),
                  rowtext(Icons.date_range, "date",
                      snapshot.data[index]['datetime']),
                  verticalSpaceSmall,
                  SizedBox(
                    height: 200,
                    child: GoogleMap(
                      initialCameraPosition: CameraPosition(
                        target: LatLng(latitude, longitude),
                        zoom: 15.0,
                      ),
                      markers: {
                        Marker(
                          markerId: const MarkerId('marker'),
                          position: LatLng(latitude, longitude),
                        ),
                      },
                    ),
                  ),
                ],
              ),
            ),
            drop(snapshot: snapshot, index: index, check: check)
          ],
        ),
      ),
    );
  }

  Widget rowtext(IconData iconData, String title, String des) {
    return Row(
      children: [
        Icon(
          iconData,
          color: white,
        ),
        horizontalSpaceTiny,
        text_helper(
          data: title,
          font: poppins,
          color: white,
          size: fontSize14,
          bold: true,
        ),
        horizontalSpaceTiny,
        Expanded(
            child: text_helper(
                data: des,
                font: poppins,
                textAlign: TextAlign.start,
                color: white,
                size: fontSize12))
      ],
    );
  }

  Widget topview(OrdersViewModel viewModel, String txt) {
    return InkWell(
      onTap: () {
        viewModel.filter = txt;
        viewModel.notifyListeners();
      },
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
        margin: const EdgeInsets.all(5),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            color: txt == viewModel.filter ? kcPrimaryColorDark : white,
            boxShadow: [
              BoxShadow(
                  color: getColorWithOpacity(kcLightGrey, 0.4),
                  blurRadius: 1,
                  spreadRadius: 1,
                  offset: const Offset(2, 2))
            ]),
        child: text_helper(
            data: txt,
            font: poppins,
            bold: true,
            color: txt != viewModel.filter ? kcPrimaryColorDark : white,
            size: fontSize14),
      ),
    );
  }

  @override
  OrdersViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      OrdersViewModel();
}

class drop extends StatefulWidget {
  drop(
      {super.key,
      required this.snapshot,
      required this.index,
      required this.check});
  AsyncSnapshot snapshot;
  int index;
  bool check;

  @override
  State<drop> createState() => _dropState();
}

class _dropState extends State<drop> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        widget.snapshot.data[widget.index]['status'] == 'new' && !widget.check
            ? Container(
                width: screenWidth(context),
                padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                margin: const EdgeInsets.fromLTRB(5, 0, 5, 5),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10), color: white),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    text_helper(
                        data: "Aspect",
                        font: poppins,
                        color: kcPrimaryColorDark,
                        size: fontSize12),
                    Container(
                      width: screenWidth(context),
                      margin: const EdgeInsets.all(5),
                      padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
                      decoration: BoxDecoration(boxShadow: [
                        BoxShadow(
                            offset: const Offset(2, 2),
                            blurRadius: 1,
                            spreadRadius: 1,
                            color: getColorWithOpacity(kcPrimaryColorDark, 0.2))
                      ], borderRadius: BorderRadius.circular(10), color: white),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              const Icon(
                                Icons.merge_type,
                                color: kcDarkGreyColor,
                              ),
                              horizontalSpaceTiny,
                              text_helper(
                                  data: (widget.snapshot.data[widget.index]
                                                  ['type'] ==
                                              'Diesel' ||
                                          widget.snapshot.data[widget.index]
                                                  ['type'] ==
                                              'Fuel')
                                      ? "Rider Type"
                                      : "Mechanics Type",
                                  font: poppins,
                                  color: kcDarkGreyColor,
                                  size: fontSize12),
                            ],
                          ),
                          FutureBuilder(
                            future: ApiHelper.getmechanics(),
                            builder: (BuildContext context,
                                AsyncSnapshot snapshot2) {
                              if (snapshot2.hasData) {
                                mechanics(
                                    snapshot2.data as List,
                                    (widget.snapshot.data[widget.index]
                                                    ['type'] ==
                                                'Diesel' ||
                                            widget.snapshot.data[widget.index]
                                                    ['type'] ==
                                                'Fuel')
                                        ? "r"
                                        : "m");
                                return DropdownButton<String>(
                                  value: ms,
                                  underline: const SizedBox.shrink(),
                                  onChanged: (String? newValue) {
                                    ms = newValue!;
                                    setState(() {});
                                  },
                                  items: m.map<DropdownMenuItem<String>>(
                                      (String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: text_helper(
                                          data: value,
                                          font: poppins,
                                          color: kcDarkGreyColor,
                                          size: fontSize12),
                                    );
                                  }).toList(),
                                );
                              } else if (snapshot2.hasError) {
                                return const Icon(
                                  Icons.error,
                                  color: kcDarkGreyColor,
                                );
                              } else {
                                return displaysimpleprogress(context);
                              }
                            },
                          ),
                        ],
                      ),
                    ),
                    Row(
                      children: [
                        button_helper(
                            onpress: () => aspectnew(context,
                                widget.snapshot.data[widget.index]['_id']),
                            color: kcPrimaryColorDark,
                            width: screenWidthCustom(context, 0.35),
                            child: text_helper(
                              data: "Aspect Order",
                              font: poppins,
                              color: white,
                              size: fontSize14,
                              bold: true,
                            )),
                        button_helper(
                            onpress: () => reject(context,
                                widget.snapshot.data[widget.index]['_id']),
                            color: Colors.red,
                            width: screenWidthCustom(context, 0.35),
                            child: text_helper(
                              data: "Reject Order",
                              font: poppins,
                              color: white,
                              size: fontSize14,
                              bold: true,
                            )),
                      ],
                    )
                  ],
                ),
              )
            : const SizedBox.shrink(),
        widget.snapshot.data[widget.index]['status'] == 'in progress' &&
                widget.check
            ? button_helper(
                onpress: () => inprogresstoend(
                    context,
                    widget.snapshot.data[widget.index]['_id'],
                    widget.snapshot.data[widget.index]['mechanicsid']),
                color: kcPrimaryColorDark,
                width: screenWidthCustom(context, 0.4),
                child: text_helper(
                  data: "Done your work",
                  font: poppins,
                  color: white,
                  size: fontSize14,
                  bold: true,
                ))
            : const SizedBox.shrink()
      ],
    );
  }

  String ms = '';
  bool c = true;
  List<String> m = [];
  List newmechanics = [];

  void mechanics(List l, String type) {
    if (c) {
      newmechanics = l;
      for (var element in l) {
        if (element['status'] == 'free') {
          print(element['typerm']);
          if (element['typerm'] == type) {
            m.add(element['name']);
          }
        }
      }
      if (m.isNotEmpty) {
        ms = m[0];
      } else {
        m.add('');
        ms = '';
      }
      c = false;
    }
  }

  Future<void> inprogresstoend(
      BuildContext context, String number, String idd) async {
    print(idd);
    bool c = await ApiHelper.updatestatus(number, "end", idd, context);
    if (c) {
      bool f = await ApiHelper.updatemechanics(idd, 'free', context);
    }
  }

  Future<void> reject(BuildContext context, String number) async {
    await ApiHelper.updatestatus(number, "reject", "", context);
    Navigator.pop(context);
  }

  Future<void> aspectnew(BuildContext context, String number) async {
    String id = '';
    for (var element in newmechanics) {
      if (element['name'] == ms) {
        id = element['_id'];
      }
    }
    if (id != '') {
      bool c = await ApiHelper.updatestatus(number, "in progress", id, context);
      if (c) {
        bool f = await ApiHelper.updatemechanics(id, 'not free', context);
      }
    } else {
      show_snackbar(context, "Select a rider");
    }
  }
}
