import 'package:custom_clippers/Clippers/sin_cosine_wave_clipper.dart';
import 'package:flutter/material.dart';
import 'package:indus/ui/common/app_colors.dart';
import 'package:indus/ui/common/uihelper/button_helper.dart';
import 'package:indus/ui/widgets/common/addnotifications/addnotifications.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_strings.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/text_helper.dart';
import 'admin_viewmodel.dart';

class AdminView extends StackedView<AdminViewModel> {
  const AdminView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    AdminViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: white,
      body: SafeArea(
        child: ListView(
          children: [
            top(context),
            Container(
              padding: const EdgeInsets.all(10),
              height: 270,
              width: screenWidth(context),
              child: GridView.count(
                  scrollDirection: Axis.horizontal,
                  crossAxisCount: 2,
                  children: [
                    girddata("Wallet", "assets/wallet.png", context, viewModel),
                    girddata("Top-Up", "assets/Top-Up.png", context, viewModel),
                    girddata("mechanics", "assets/mechanics.png", context,
                        viewModel),
                    girddata("Riders", "assets/rider.png", context, viewModel),
                    girddata("Analytics", "assets/Analytics.png", context,
                        viewModel),
                    girddata("Orders", "assets/order.png", context, viewModel),
                    girddata("Notifications", "assets/notifications.png",
                        context, viewModel),
                    girddata("complaints", "assets/complaints.png", context,
                        viewModel),
                  ]),
            ),
            button_helper(
                onpress: () => viewModel.logout(),
                color: kcPrimaryColorDark,
                width: screenWidthCustom(context, 0.4),
                child: text_helper(
                  data: "Logout",
                  font: poppins,
                  color: white,
                  size: fontSize16,
                  bold: true,
                ))
          ],
        ),
      ),
    );
  }

  Widget girddata(
      String txt, String img, BuildContext context, AdminViewModel viewModel) {
    return InkWell(
      onTap: () {
        if (txt == 'mechanics') {
          viewModel.mechanics();
        } else if (txt == 'Orders') {
          viewModel.order();
        } else if (txt == 'Notifications') {
          notification(context);
        } else if (txt == 'complaints') {
          viewModel.complaint();
        }
      },
      child: Container(
        margin: const EdgeInsets.all(10),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: white,
            boxShadow: [
              BoxShadow(
                  color: getColorWithOpacity(kcLightGrey, 0.4),
                  blurRadius: 2,
                  spreadRadius: 2,
                  offset: const Offset(2, 2))
            ]),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              img,
              width: screenWidthCustom(context, 0.11),
              height: screenWidthCustom(context, 0.11),
              color: kcPrimaryColorDark,
            ),
            text_helper(
                data: txt,
                font: poppins,
                bold: true,
                color: kcPrimaryColorDark,
                size: fontSize10)
          ],
        ),
      ),
    );
  }

  void notification(BuildContext context) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return const Dialog(
            backgroundColor: white,
            child: Addnotifications(),
          );
        });
  }

  Widget top(BuildContext context) {
    return ClipPath(
      clipper: SinCosineWaveClipper(),
      child: Container(
          height: 200,
          width: screenWidth(context),
          padding: const EdgeInsets.all(10),
          decoration: const BoxDecoration(
              gradient:
                  LinearGradient(colors: [kcPrimaryColorDark, kcPrimaryColor])),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              text_helper(
                  data: "Welcome",
                  font: poppins,
                  color: white,
                  size: fontSize10),
              text_helper(
                data: "Admin Panel",
                font: poppins,
                color: white,
                size: fontSize18,
                bold: true,
              ),
              const Divider(
                height: 2,
              ),
              verticalSpaceSmall,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          text_helper(
                              data: "Available Balance",
                              font: poppins,
                              color: white,
                              size: fontSize10),
                          text_helper(
                            data: "Rs 0.0",
                            font: poppins,
                            color: white,
                            size: fontSize14,
                            bold: true,
                          ),
                          text_helper(
                              data: "Point Balance",
                              font: poppins,
                              color: white,
                              size: fontSize10),
                          text_helper(
                            data: "0",
                            font: poppins,
                            color: white,
                            size: fontSize14,
                            bold: true,
                          ),
                        ],
                      ),
                      horizontalSpaceSmall,
                      Container(
                        margin: const EdgeInsets.only(top: 10),
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                            color: white,
                            borderRadius: BorderRadius.circular(50)),
                        child: const Icon(
                          Icons.add,
                          color: kcPrimaryColor,
                        ),
                      )
                    ],
                  ),
                  text_helper(
                      data: "DIGICASH",
                      font: poppins,
                      bold: true,
                      color: Colors.amber,
                      size: fontSize16)
                ],
              )
            ],
          )),
    );
  }

  @override
  void onViewModelReady(AdminViewModel viewModel) {
    viewModel.permission();
    super.onViewModelReady(viewModel);
  }

  @override
  AdminViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      AdminViewModel();
}
