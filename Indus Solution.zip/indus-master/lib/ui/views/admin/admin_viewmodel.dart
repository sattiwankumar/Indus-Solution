import 'package:indus/ui/views/complaints/complaints_view.dart';
import 'package:indus/ui/views/mechanics/mechanics_view.dart';
import 'package:indus/ui/views/orders/orders_view.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../services/sharedpref_service.dart';
import '../login/login_view.dart';
import '../wallet/wallet_view.dart';

class AdminViewModel extends BaseViewModel {
  final sharedpref = locator<SharedprefService>();
  final _navigationService = locator<NavigationService>();

  void mechanics(String type) {
    _navigationService.navigateWithTransition(
        MechanicsView(
          type: type,
        ),
        routeName: Routes.mechanicsView,
        transitionStyle: Transition.rightToLeft);
  }

  void complaint() {
    _navigationService.navigateWithTransition(const ComplaintsView(),
        routeName: Routes.complaintsView,
        transitionStyle: Transition.rightToLeft);
  }

  void order() {
    _navigationService.navigateWithTransition(
        OrdersView(
          check: false,
        ),
        routeName: Routes.ordersView,
        transitionStyle: Transition.rightToLeft);
  }

  void wallet() {
    _navigationService.navigateWithTransition(const WalletView(),
        routeName: Routes.walletView, transitionStyle: Transition.rightToLeft);
  }

  void logout() {
    sharedpref.remove('deviceid');
    sharedpref.remove('auth');
    _navigationService.clearStackAndShow(Routes.loginView);
    _navigationService.replaceWithTransition(const LoginView(),
        routeName: Routes.loginView, transitionStyle: Transition.rightToLeft);
  }

  Future<void> permission() async {
    await Permission.notification.request();
  }
}
