import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../common/uihelper/snakbar_helper.dart';

class HomeViewModel extends BaseViewModel {
  final _dialogService = locator<DialogService>();

  int currentIndex = 0;
  void updateindex(int index) {
    currentIndex = index;
    notifyListeners();
  }

  void scan(BuildContext context) {
    _dialogService
        .showCustomDialog(variant: DialogType.infoAlert)
        .then((value) {
      if (value!.data['pin'] == '') {
        show_snackbar(context, "No Qr Scan");
      } else {}
    });
  }

  Future<void> permission() async {
    await Permission.notification.request();
  }
}
