import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:indus/ui/common/app_colors.dart';
import 'package:indus/ui/common/ui_helpers.dart';
import 'package:indus/ui/widgets/common/faqs/faqs.dart';
import 'package:indus/ui/widgets/common/homedetails/homedetails.dart';
import 'package:indus/ui/widgets/common/setting/setting.dart';
import 'package:stacked/stacked.dart';
import 'package:stylish_bottom_bar/model/bar_items.dart';
import 'package:stylish_bottom_bar/stylish_bottom_bar.dart';

import '../../widgets/common/noifications/noifications.dart';
import 'home_viewmodel.dart';

class HomeView extends StackedView<HomeViewModel> {
  const HomeView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    HomeViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: white,
      extendBody: true,
      body: SafeArea(
        child: bodyContainer(viewModel, context),
      ),
      bottomNavigationBar: StylishBottomBar(
        option: AnimatedBarOptions(
          barAnimation: BarAnimation.fade,
          iconStyle: IconStyle.animated,
        ),
        items: [
          BottomBarItem(
            icon: const Icon(
              Icons.house_outlined,
            ),
            selectedIcon: const Icon(Icons.house_rounded),
            backgroundColor: kcPrimaryColorDark,
            title: const Text('Home'),
          ),
          BottomBarItem(
            icon: const Icon(Icons.notifications_active_outlined),
            selectedIcon: const Icon(Icons.notifications_active),
            backgroundColor: kcPrimaryColorDark,
            title: const Text('Notification'),
          ),
          BottomBarItem(
              icon: const Icon(Icons.question_answer_outlined),
              selectedIcon: const Icon(
                Icons.question_answer,
              ),
              backgroundColor: kcPrimaryColorDark,
              title: const Text('Faqs')),
          BottomBarItem(
              icon: const Icon(
                Icons.settings,
              ),
              selectedIcon: const Icon(
                Icons.settings,
              ),
              backgroundColor: kcPrimaryColorDark,
              title: const Text('Setting')),
        ],
        hasNotch: true,
        fabLocation: StylishBarFabLocation.center,
        currentIndex: viewModel.currentIndex,
        onTap: (index) => viewModel.updateindex(index),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => viewModel.scan(context),
        backgroundColor: kcPrimaryColorDark,
        child: const Icon(
          Icons.qr_code,
          color: white,
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  Widget bodyContainer(HomeViewModel viewModel, BuildContext context) {
    Widget screen = const Homedetails();
    switch (viewModel.currentIndex) {
      case 0:
        screen =
            const Homedetails().animate().fadeIn(duration: 500.milliseconds);
        break;
      case 1:
        screen =
            const Noifications().animate().fadeIn(duration: 500.milliseconds);
        break;
      case 2:
        screen = const Faqs().animate().fadeIn(duration: 500.milliseconds);
        break;
      case 3:
        screen = const Setting().animate().fadeIn(duration: 500.milliseconds);
        break;
    }

    return SizedBox(
      width: screenWidth(context),
      height: screenHeight(context),
      child: Center(child: screen),
    );
  }

  @override
  void onViewModelReady(HomeViewModel viewModel) {
    viewModel.permission();
    super.onViewModelReady(viewModel);
  }

  @override
  HomeViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      HomeViewModel();
}
