import 'package:flutter/cupertino.dart';
import 'package:flutter_masked_text2/flutter_masked_text2.dart';
import 'package:indus/ui/common/apihelpers/firebsaeuploadhelper.dart';
import 'package:indus/ui/views/admin/admin_view.dart';
import 'package:indus/ui/views/signup/signup_view.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../services/fire_service.dart';
import '../../../services/sharedpref_service.dart';
import '../../common/apihelpers/apihelper.dart';
import '../../common/uihelper/snakbar_helper.dart';
import '../home/home_view.dart';

class LoginViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final _sharedpref = locator<SharedprefService>();
  final _fireService = locator<FireService>();

  TextEditingController phone = MaskedTextController(mask: '0000-0000000');
  TextEditingController pass = TextEditingController();

  bool _validatePhoneNumber(String value) {
    final RegExp phoneNumberRegExp = RegExp(r'^03[0-9]{2}-[0-9]{7}$');
    return phoneNumberRegExp.hasMatch(value);
  }

  void login(BuildContext context) {
    if (phone.text.isEmpty || pass.text.isEmpty) {
      show_snackbar(context, "fill all fields");
    } else if (phone.text.length != 12) {
      show_snackbar(context, "Number is not correct");
    } else if (phone.text.toString() == '0000-0000000' &&
        pass.text.toString() == 'admin') {
      var result = _fireService.messaging.getToken().then((value) {
        return ApiHelper.registeradmin(value.toString(), context);
      });
      result.then((value) {
        _sharedpref.setString('number', phone.text);
        _sharedpref.setString('name', "Admin");
        _sharedpref.setString("auth", 'true');
        _sharedpref.setString("deviceid", value['did']);
        FirebaseHelper.sendnotificationto(
            value['did'], "Login", "Admin logged in Sucessfully");
        _navigationService.clearStackAndShow(Routes.adminView);
        _navigationService.replaceWithTransition(const AdminView(),
            routeName: Routes.adminView,
            transitionStyle: Transition.rightToLeft);
      });
    } else if (!_validatePhoneNumber(phone.text)) {
      show_snackbar(
          context, "Number is not correct write in form 0300-0000000");
    } else {
      displayprogress(context);
      var result = _fireService.messaging.getToken().then((value) {
        return ApiHelper.login(
            phone.text, pass.text, value.toString(), context);
      });
      result.then((value) {
        if (value.toString() != "{}") {
          _sharedpref.setString('name', value['name']);
          _sharedpref.setString('cnic', value['cnic']);
          _sharedpref.setString('number', phone.text);
          _sharedpref.setString('address', value['address']);
          _sharedpref.setString('dob', value['dob']);
          _sharedpref.setString('deviceid', value['deviceid']);
          _sharedpref.setString('img', value['img']);

          _sharedpref.setString("auth", 'true');
          hideprogress(context);

          FirebaseHelper.sendnotificationto(value['deviceid'], "Login",
              "${value['name']} logged in Sucessfully");
          _navigationService.clearStackAndShow(Routes.homeView);
          _navigationService.replaceWithTransition(const HomeView(),
              routeName: Routes.homeView,
              transitionStyle: Transition.rightToLeft);
        }
      });
    }
  }

  void signup() {
    _navigationService.navigateWithTransition(const SignupView(),
        routeName: Routes.signupView, transitionStyle: Transition.rightToLeft);
  }
}
