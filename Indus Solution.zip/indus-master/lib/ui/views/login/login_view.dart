import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:indus/ui/common/app_colors.dart';
import 'package:indus/ui/common/app_strings.dart';
import 'package:indus/ui/common/ui_helpers.dart';
import 'package:indus/ui/common/uihelper/text_helper.dart';
import 'package:indus/ui/widgets/common/top/top.dart';
import 'package:stacked/stacked.dart';

import '../../common/uihelper/button_helper.dart';
import '../../common/uihelper/text_veiw_helper.dart';
import 'login_viewmodel.dart';

class LoginView extends StackedView<LoginViewModel> {
  const LoginView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    LoginViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: Column(
            children: [
              Top(
                textdown: "Login",
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(15, 25, 15, 0),
                  child: Column(
                    children: [
                      text_view_helper(
                        hint: "Enter Phone Number",
                        controller: viewModel.phone,
                        showicon: true,
                        maxlength: 11,
                        formatter: [
                          FilteringTextInputFormatter.allow(getRegExpint())
                        ],
                        textInputType: TextInputType.phone,
                        icon: const Icon(Icons.call),
                      )
                          .animate(delay: 900.milliseconds)
                          .fade()
                          .moveY(begin: 50, end: 0),
                      text_view_helper(
                        hint: "Enter Password",
                        controller: viewModel.pass,
                        obsecure: true,
                        showicon: true,
                        icon: const Icon(Icons.password),
                      )
                          .animate(delay: 1100.milliseconds)
                          .fade()
                          .moveY(begin: 50, end: 0),
                    ],
                  ),
                ),
              ),
              button_helper(
                      onpress: () => viewModel.login(context),
                      color: kcPrimaryColorDark,
                      width: screenHeightCustom(context, 0.3),
                      child: text_helper(
                        data: "Login",
                        font: poppins,
                        color: white,
                        size: fontSize14,
                        bold: true,
                      ))
                  .animate(delay: 1300.milliseconds)
                  .fade()
                  .moveY(begin: 50, end: 0),
              InkWell(
                onTap: () => viewModel.signup(),
                child: text_helper(
                  data: "Do not have Account",
                  font: poppins,
                  color: kcDarkGreyColor,
                  size: fontSize12,
                ),
              )
                  .animate(delay: 1500.milliseconds)
                  .fade()
                  .moveY(begin: 50, end: 0),
              verticalSpaceMedium,
            ],
          ),
        ));
  }

  @override
  LoginViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      LoginViewModel();
}
