import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:indus/ui/common/app_colors.dart';
import 'package:indus/ui/common/app_strings.dart';
import 'package:indus/ui/common/ui_helpers.dart';
import 'package:indus/ui/common/uihelper/text_helper.dart';
import 'package:lottie/lottie.dart';
import 'package:stacked/stacked.dart';

import 'startup_viewmodel.dart';

class StartupView extends StackedView<StartupViewModel> {
  const StartupView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    StartupViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: white,
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                      width: screenWidthCustom(context, 0.3),
                      height: screenWidthCustom(context, 0.3),
                      child: Lottie.asset('assets/loading.json'))
                  .animate(delay: 500.milliseconds)
                  .fade()
                  .moveY(begin: 50, end: 0),
              text_helper(
                data: "Indus Solution",
                font: poppins,
                color: kcDarkGreyColor,
                size: fontSize22,
                bold: true,
              ).animate(delay: 700.milliseconds).fade().moveY(begin: 50, end: 0)
            ],
          ),
        ),
      ),
    );
  }

  @override
  StartupViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      StartupViewModel();

  @override
  void onViewModelReady(StartupViewModel viewModel) => SchedulerBinding.instance
      .addPostFrameCallback((timeStamp) => viewModel.runStartupLogic());
}
