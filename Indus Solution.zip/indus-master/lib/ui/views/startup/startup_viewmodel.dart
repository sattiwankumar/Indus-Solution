import 'package:indus/ui/views/login/login_view.dart';
import 'package:stacked/stacked.dart';
import 'package:indus/app/app.locator.dart';
import 'package:indus/app/app.router.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../services/sharedpref_service.dart';
import '../admin/admin_view.dart';
import '../home/home_view.dart';

class StartupViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final _sharedpref = locator<SharedprefService>();

  Future runStartupLogic() async {
    _sharedpref.initialize();
    await Future.delayed(const Duration(seconds: 3));
    if (_sharedpref.contains('auth') &&
        _sharedpref.readString('auth') == 'true') {
      if (_sharedpref.readString('number') == '0000-0000000') {
        _navigationService.replaceWithTransition(const AdminView(),
            routeName: Routes.adminView,
            transitionStyle: Transition.rightToLeft);
      } else {
        _navigationService.replaceWithTransition(const HomeView(),
            routeName: Routes.homeView,
            transitionStyle: Transition.rightToLeft);
      }
    } else {
      _navigationService.replaceWithTransition(const LoginView(),
          routeName: Routes.loginView, transitionStyle: Transition.rightToLeft);
    }
  }
}
