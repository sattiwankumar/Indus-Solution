import 'package:flutter/material.dart';
import 'package:indus/ui/common/app_colors.dart';
import 'package:stacked/stacked.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../../common/apihelpers/apihelper.dart';
import '../../common/app_strings.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/snakbar_helper.dart';
import '../../common/uihelper/text_helper.dart';
import '../../widgets/common/top2/top2.dart';
import '../wallet/wallet_viewmodel.dart';
import 'analytics_viewmodel.dart';

class AnalyticsView extends StackedView<AnalyticsViewModel> {
  const AnalyticsView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    AnalyticsViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: Column(
            children: [
              Top2(txt: "Analytics"),
              Expanded(
                child: FutureBuilder(
                  future: data(viewModel),
                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                    if (snapshot.hasData) {
                      return Column(
                        children: [
                          SfCartesianChart(
                              primaryXAxis: const CategoryAxis(),
                              borderWidth: 4,
                              plotAreaBorderWidth: 0,
                              title: ChartTitle(
                                  text: "Fuel Report",
                                  textStyle: text_helper.customstyle(
                                      poppins,
                                      kcDarkGreyColor,
                                      fontSize12,
                                      context,
                                      true)),
                              primaryYAxis: const NumericAxis(
                                  minimum: 0, maximum: 50, interval: 10),
                              tooltipBehavior: TooltipBehavior(enable: true),
                              series: <CartesianSeries>[
                                ColumnSeries<ChartData, String>(
                                    dataSource: snapshot.data,
                                    xValueMapper: (ChartData data, _) => data.x,
                                    yValueMapper: (ChartData data, _) => data.y,
                                    name:
                                        viewModel.sharedpref.readString('name'),
                                    color:
                                        getColorWithOpacity(kcPrimaryColor, 1))
                              ])
                        ],
                      );
                    } else if (snapshot.hasError) {
                      return const Icon(
                        Icons.error,
                        color: kcDarkGreyColor,
                      );
                    } else {
                      return displaysimpleprogress(context);
                    }
                  },
                ),
              ),
            ],
          ),
        ));
  }

  Future<List<ChartData>> data(AnalyticsViewModel viewModel) async {
    List a = await ApiHelper.getorderbynum(
        viewModel.sharedpref.readString('number'));
    Map f = {};
    for (var value in a) {
      if (value['type'] == "Fuel") {
        bool h = false;
        for (var value2 in f.keys) {
          if (value2 == value['datetime'].toString().substring(0, 10)) {
            value2 += int.parse(value['quantity']);
            h = true;
            break;
          } else {
            h = false;
          }
        }
        if (!h) {
          f[value['datetime'].toString().substring(0, 10)] =
              int.parse(value['quantity']);
        }
      }
    }

    List<ChartData> ff = [];
    f.forEach((k, v) {
      ff.add(ChartData(k, double.parse(v.toString())));
    });

    return ff;
  }

  @override
  AnalyticsViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      AnalyticsViewModel();
}
