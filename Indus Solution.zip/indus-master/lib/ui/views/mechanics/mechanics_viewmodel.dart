import 'package:stacked/stacked.dart';

class MechanicsViewModel extends BaseViewModel {}
