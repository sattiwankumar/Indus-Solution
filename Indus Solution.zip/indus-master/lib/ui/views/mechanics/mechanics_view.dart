import 'package:cached_network_image/cached_network_image.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:indus/ui/common/app_colors.dart';
import 'package:indus/ui/common/app_strings.dart';
import 'package:indus/ui/common/ui_helpers.dart';
import 'package:indus/ui/common/uihelper/text_helper.dart';
import 'package:indus/ui/widgets/common/addmechanics/addmechanics.dart';
import 'package:indus/ui/widgets/common/top2/top2.dart';
import 'package:stacked/stacked.dart';

import '../../common/apihelpers/apihelper.dart';
import '../../common/uihelper/snakbar_helper.dart';
import 'mechanics_viewmodel.dart';

class MechanicsView extends StackedView<MechanicsViewModel> {
  const MechanicsView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    MechanicsViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: white,
      body: SafeArea(
        child: Column(
          children: [
            Top2(
              txt: 'Mechanics Managment',
            ),
            Expanded(
              child: FutureBuilder(
                future: ApiHelper.getmechanics(),
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (snapshot.hasData) {
                    return ListView.builder(
                      itemCount: snapshot.data.length,
                      itemBuilder: (BuildContext context, int index) {
                        return Container(
                          width: screenWidth(context),
                          margin: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                              boxShadow: [
                                BoxShadow(
                                    offset: const Offset(2, 2),
                                    blurRadius: 1,
                                    spreadRadius: 1,
                                    color: getColorWithOpacity(
                                        kcPrimaryColorDark, 0.2))
                              ],
                              borderRadius: BorderRadius.circular(10),
                              color: white),
                          child: DottedBorder(
                            borderType: BorderType.RRect,
                            radius: const Radius.circular(10),
                            padding: const EdgeInsets.all(10),
                            dashPattern: const [8, 4],
                            color: snapshot.data[index]['status'] == 'free'
                                ? Colors.green
                                : Colors.red,
                            child: Row(
                              children: [
                                CachedNetworkImage(
                                  imageUrl: snapshot.data[index]['profile'],
                                  imageBuilder: (context, imageProvider) =>
                                      ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Container(
                                      padding:
                                          const EdgeInsetsDirectional.all(2),
                                      color: white,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(10),
                                        child: Container(
                                          width:
                                              screenWidthCustom(context, 0.2),
                                          height:
                                              screenWidthCustom(context, 0.2),
                                          decoration: BoxDecoration(
                                            image: DecorationImage(
                                              image: imageProvider,
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  placeholder: (context, url) =>
                                      displaysimpleprogress(context),
                                  errorWidget: (context, url, error) =>
                                      const Icon(Icons.error),
                                ),
                                horizontalSpaceSmall,
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        text_helper(
                                            data: snapshot.data[index]['name'],
                                            font: poppins,
                                            bold: true,
                                            color: kcDarkGreyColor,
                                            size: fontSize16),
                                        Container(
                                          padding: const EdgeInsets.fromLTRB(
                                              15, 2, 15, 2),
                                          margin: const EdgeInsets.all(5),
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            color: snapshot.data[index]
                                                        ['status'] ==
                                                    'free'
                                                ? Colors.green
                                                : Colors.red,
                                          ),
                                          child: text_helper(
                                            data: snapshot.data[index]
                                                ['status'],
                                            font: poppins,
                                            color: white,
                                            size: fontSize14,
                                            bold: true,
                                          ),
                                        )
                                      ],
                                    ),
                                    text_helper(
                                        data: snapshot.data[index]['number'],
                                        font: poppins,
                                        color: kcDarkGreyColor,
                                        size: fontSize10),
                                    text_helper(
                                        data: snapshot.data[index]['type'],
                                        font: poppins,
                                        bold: true,
                                        color: kcDarkGreyColor,
                                        size: fontSize10),
                                    text_helper(
                                        data: snapshot.data[index]['address'],
                                        font: poppins,
                                        color: kcDarkGreyColor,
                                        size: fontSize10),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  } else if (snapshot.hasError) {
                    return const Icon(
                      Icons.error,
                      color: kcDarkGreyColor,
                    );
                  } else {
                    return displaysimpleprogress(context);
                  }
                },
              ),
            )
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => addmechanics(context),
        backgroundColor: kcPrimaryColorDark,
        child: const Icon(
          Icons.add,
          color: white,
          size: 50,
        ),
      ),
    );
  }

  void addmechanics(BuildContext context) {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (BuildContext context) {
          return const Addmechanics();
        });
  }

  @override
  MechanicsViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      MechanicsViewModel();
}
