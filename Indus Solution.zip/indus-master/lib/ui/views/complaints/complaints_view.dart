import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:indus/ui/common/app_colors.dart';
import 'package:indus/ui/widgets/common/top2/top2.dart';
import 'package:stacked/stacked.dart';

import '../../common/apihelpers/apihelper.dart';
import '../../common/app_strings.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/snakbar_helper.dart';
import '../../common/uihelper/text_helper.dart';
import 'complaints_viewmodel.dart';

class ComplaintsView extends StackedView<ComplaintsViewModel> {
  const ComplaintsView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    ComplaintsViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
            child: Column(
          children: [
            Top2(txt: "Complaints"),
            verticalSpaceSmall,
            Expanded(
              child: FutureBuilder(
                future: ApiHelper.allcomplaint(context),
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (snapshot.hasData) {
                    return ListView.builder(
                      itemCount: snapshot.data.length,
                      itemBuilder: (BuildContext context, int index) {
                        return Container(
                            width: screenWidth(context),
                            margin: const EdgeInsets.only(
                                left: 10, right: 10, bottom: 10),
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(10)),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.deepPurple.withOpacity(0.1),
                                  spreadRadius: 1,
                                  blurRadius: 1,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  FutureBuilder(
                                    future: ApiHelper.getoneuseronnumber(
                                        snapshot.data[index]['addedby']),
                                    builder: (BuildContext context,
                                        AsyncSnapshot snapshot2) {
                                      if (snapshot2.hasData) {
                                        if (snapshot2.data.toString() == '{}') {
                                          return Center(
                                            child: text_helper(
                                                data: "No Data",
                                                font: poppins,
                                                color: kcDarkGreyColor,
                                                size: fontSize14),
                                          );
                                        } else {
                                          return Row(
                                            children: [
                                              CachedNetworkImage(
                                                imageUrl: snapshot2.data['img'],
                                                imageBuilder:
                                                    (context, imageProvider) =>
                                                        ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  child: Container(
                                                    width: screenWidthCustom(
                                                        context, 0.12),
                                                    height: screenWidthCustom(
                                                        context, 0.12),
                                                    decoration: BoxDecoration(
                                                      image: DecorationImage(
                                                        image: imageProvider,
                                                        fit: BoxFit.cover,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                placeholder: (context, url) =>
                                                    displaysimpleprogress(
                                                        context),
                                                errorWidget:
                                                    (context, url, error) =>
                                                        const Icon(
                                                  Icons.error,
                                                  color: kcDarkGreyColor,
                                                ),
                                              ),
                                              horizontalSpaceTiny,
                                              Expanded(
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .symmetric(
                                                                horizontal:
                                                                    8.0),
                                                        child: text_helper(
                                                          data: snapshot2
                                                              .data['name'],
                                                          font: poppins,
                                                          color: kcPrimaryColor,
                                                          size: fontSize16,
                                                          bold: true,
                                                        )),
                                                    Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .symmetric(
                                                                horizontal:
                                                                    8.0),
                                                        child: text_helper(
                                                            data: snapshot
                                                                    .data[index]
                                                                ['addedby'],
                                                            font: poppins,
                                                            color:
                                                                kcDarkGreyColor,
                                                            size: fontSize12)),
                                                  ],
                                                ),
                                              )
                                            ],
                                          );
                                        }
                                      } else if (snapshot2.hasError) {
                                        return const Icon(
                                          Icons.error,
                                          color: kcDarkGreyColor,
                                        );
                                      } else {
                                        return displaysimpleprogress(context);
                                      }
                                    },
                                  ),
                                  verticalSpaceSmall,
                                  Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8.0),
                                      child: text_helper(
                                        data: snapshot.data[index]['title'],
                                        font: poppins,
                                        color: Colors.red,
                                        size: fontSize16,
                                        bold: true,
                                      )),
                                  Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8.0),
                                      child: text_helper(
                                          data: snapshot.data[index]['ans'],
                                          font: poppins,
                                          color: kcDarkGreyColor,
                                          size: fontSize14)),
                                  Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8.0),
                                      child: text_helper(
                                          data: snapshot.data[index]['time']
                                              .toString()
                                              .substring(0, 16),
                                          font: poppins,
                                          color: kcDarkGreyColor,
                                          size: fontSize10)),
                                ]));
                      },
                    );
                  } else if (snapshot.hasError) {
                    return const Icon(
                      Icons.error,
                    );
                  } else {
                    return displaysimpleprogress(context);
                  }
                },
              ),
            )
          ],
        )));
  }

  @override
  ComplaintsViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      ComplaintsViewModel();
}
