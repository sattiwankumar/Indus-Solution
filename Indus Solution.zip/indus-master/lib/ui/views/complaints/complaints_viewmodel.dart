import 'package:stacked/stacked.dart';

class ComplaintsViewModel extends BaseViewModel {}
