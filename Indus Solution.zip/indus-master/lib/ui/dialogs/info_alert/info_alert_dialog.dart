import 'package:flutter/material.dart';
import 'package:indus/ui/common/app_colors.dart';
import 'package:indus/ui/common/ui_helpers.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../common/app_strings.dart';
import '../../common/uihelper/button_helper.dart';
import '../../common/uihelper/text_helper.dart';
import 'info_alert_dialog_model.dart';

class InfoAlertDialog extends StackedView<InfoAlertDialogModel> {
  final DialogRequest request;
  final Function(DialogResponse) completer;

  const InfoAlertDialog({
    Key? key,
    required this.request,
    required this.completer,
  }) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    InfoAlertDialogModel viewModel,
    Widget? child,
  ) {
    return Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        backgroundColor: Colors.white,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: screenWidthCustom(context, 0.8),
              height: screenWidthCustom(context, 0.8),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: getColorWithOpacity(kcPrimaryColor, 0.3)),
              child: QRView(
                key: viewModel.globalKey,
                onQRViewCreated: (QRViewController controller) {
                  controller.scannedDataStream.listen((event) {
                    viewModel.pin = event.code!;
                    if (viewModel.count > 1) {
                      viewModel.back();
                    }
                    viewModel.count++;
                  });
                },
                cameraFacing: CameraFacing.back,
                overlayMargin: const EdgeInsets.all(10),
              ),
            ),
            button_helper(
                onpress: () => viewModel.back(),
                color: kcPrimaryColor,
                width: screenWidthCustom(context, 0.4),
                child: text_helper(
                    data: "Cancle",
                    font: poppins,
                    color: white,
                    size: fontSize18))
          ],
        ));
  }

  @override
  InfoAlertDialogModel viewModelBuilder(BuildContext context) =>
      InfoAlertDialogModel();
}
