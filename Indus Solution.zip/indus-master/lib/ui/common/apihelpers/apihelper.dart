// ignore_for_file: depend_on_referenced_packages, use_build_context_synchronously

import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:jwt_decoder/jwt_decoder.dart';

import '../uihelper/snakbar_helper.dart';

const url = 'http://10.0.2.2:3000/';
const registrationlink = "${url}register";
const loginlink = "${url}login";
const getoneuseronnumberlink = "${url}getoneuseronnumber";

// order
const registerorderlink = "${url}registerorder";
const getorderlink = "${url}getorder";
const getorderbynumlink = "${url}getorderbynum";
const updatestatuslink = "${url}updatestatus";

// admin
const registeradminlink = '${url}registeradmin';

// mechanics
const registermechanicslink = "${url}registermechanics";
const getmechanicslink = "${url}getmechanics";
const updatemechanicslink = "${url}updatemechanics";

// faqs
const allfaqslink = "${url}allfaqs";

// notification
const registernotificationlink = "${url}registernotification";
const allnotificationlink = "${url}allnotification";

// complaint
const registercomplaintlink = "${url}registercomplaint";
const allcomplaintlink = "${url}allcomplaint";

class ApiHelper {
  // complaint
  static Future<bool> registercomplaint(
      String title, String ans, String addedby, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registercomplaintlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "title": title,
            "ans": ans,
            "time": DateTime.now().toString(),
            "addedby": addedby,
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      hideprogress(context);
      show_snackbar(context, data['message']);
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  static Future<List> allcomplaint(BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(allcomplaintlink),
          headers: {"Content-Type": "application/json"});
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['data'] as List;
    } catch (e) {
      return [];
    }
  }

  // notification
  static Future<bool> registernotification(
      String title, String ans, String url, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registernotificationlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "title": title,
            "ans": ans,
            "url": url,
            "time": DateTime.now().toString(),
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      hideprogress(context);
      show_snackbar(context, data['message']);
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  static Future<List> allnotification(BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(allnotificationlink),
          headers: {"Content-Type": "application/json"});
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['data'] as List;
    } catch (e) {
      return [];
    }
  }

  // faqs
  static Future<List> allfaqs(BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(allfaqslink),
          headers: {"Content-Type": "application/json"});
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['data'] as List;
    } catch (e) {
      return [];
    }
  }

  // mechanics
  static Future<bool> registermechanics(
      String name,
      String number,
      String cnic,
      String address,
      String type,
      String profile,
      String cnicf,
      String cnicb,
      String status,
      BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registermechanicslink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "name": name,
            "number": number,
            "cnic": cnic,
            "address": address,
            "type": type,
            "profile": profile,
            "cnicf": cnicf,
            "cnicb": cnicb,
            "status": status,
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      hideprogress(context);
      show_snackbar(context, data['sucess']);
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  static Future<List> getmechanics() async {
    try {
      var response = await http.post(Uri.parse(getmechanicslink),
          headers: {"Content-Type": "application/json"});
      return jsonDecode(utf8.decode(response.bodyBytes))['order'] as List;
    } catch (e) {
      return [];
    }
  }

  static Future<bool> updatemechanics(
      String number, String status, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(updatemechanicslink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "number": number,
            "status": status,
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      hideprogress(context);
      show_snackbar(context, data['sucess']);
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  // admin
  static Future<Map> registeradmin(String did, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registeradminlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "num": "1",
            "did": did,
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['res'] as Map;
    } catch (e) {
      show_snackbar(context, 'id not register');
      return {};
    }
  }

  // order
  static Future<bool> registerorder(
      String number,
      String quantity,
      String des,
      String type,
      String loc,
      String datetime,
      String status,
      String mechanicsid,
      BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registerorderlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "number": number,
            "quantity": quantity,
            "des": des,
            "loc": loc,
            "datetime": datetime,
            "type": type,
            "status": status,
            "mechanicsid": mechanicsid
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      hideprogress(context);
      show_snackbar(context, data['sucess']);
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  static Future<List> getorder() async {
    try {
      var response = await http.post(Uri.parse(getorderlink),
          headers: {"Content-Type": "application/json"});
      return jsonDecode(utf8.decode(response.bodyBytes))['order'] as List;
    } catch (e) {
      return [];
    }
  }

  static Future<List> getorderbynum(String number) async {
    try {
      var response = await http.post(Uri.parse(getorderbynumlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({'number': number}));
      return jsonDecode(utf8.decode(response.bodyBytes))['order'] as List;
    } catch (e) {
      return [];
    }
  }

  static Future<bool> updatestatus(String number, String status,
      String mechanicsid, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(updatestatuslink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "number": number,
            "status": status,
            "mechanicsid": mechanicsid
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      show_snackbar(context, data['sucess']);
      return data['status'] as bool;
    } catch (e) {
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  // auth
  static Future<bool> registration(
      String name,
      String cnic,
      String number,
      String address,
      String dob,
      String pass,
      String deviceid,
      String img,
      BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registrationlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "name": name,
            "cnic": cnic,
            "number": number,
            "address": address,
            "dob": dob,
            "pass": pass,
            "deviceid": deviceid,
            "img": img
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      show_snackbar(context, data['sucess']);
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'tryagainlater');
      return false;
    }
  }

  static Future<Map> login(
      String number, String pass, String deviceid, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(loginlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode(
              {"number": number, "pass": pass, "deviceid": deviceid}));
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      if (data['status']) {
        Map<String, dynamic> decodedToken = JwtDecoder.decode(data['token']);
        return decodedToken;
      } else {
        hideprogress(context);
        show_snackbar(context, data['message']);
        return {};
      }
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'try again later');
      return {};
    }
  }

  static Future<Map> getoneuseronnumber(String number) async {
    try {
      var response = await http.post(Uri.parse(getoneuseronnumberlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({'number': number}));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['a'] as Map;
    } catch (e) {
      return {};
    }
  }
}
