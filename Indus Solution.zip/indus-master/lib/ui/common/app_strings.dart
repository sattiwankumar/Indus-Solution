const String ksHomeBottomSheetTitle = 'Build Great Apps!';
const String ksHomeBottomSheetDescription =
    'Stacked is built to help you build better apps. Give us a chance and we\'ll prove it to you. Check out stacked.filledstacks.com to learn more';

// fonts
const String poppins = 'poppins';
const String roboto = 'roboto';
const String montserrat = 'montserrat';

// icons
const String baseicons = "assets/";
