import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';

import '../../../../app/app.locator.dart';
import '../../../../services/sharedpref_service.dart';
import '../../../common/apihelpers/apihelper.dart';
import '../../../common/uihelper/snakbar_helper.dart';

class AddcomplaintModel extends BaseViewModel {
  final _sharedpref = locator<SharedprefService>();

  TextEditingController name = TextEditingController();
  TextEditingController des = TextEditingController();

  Future<void> addcomplaint(BuildContext context) async {
    if (name.text.isEmpty && des.text.isEmpty) {
      show_snackbar(context, "fill all fields");
    } else {
      displayprogress(context);
      bool c = await ApiHelper.registercomplaint(
          name.text, des.text, _sharedpref.readString("number"), context);
      Navigator.pop(context);
    }
  }
}
