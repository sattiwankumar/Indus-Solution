// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:indus/ui/common/app_colors.dart';
import 'package:indus/ui/common/app_strings.dart';
import 'package:indus/ui/common/ui_helpers.dart';
import 'package:indus/ui/common/uihelper/text_helper.dart';
import 'package:lottie/lottie.dart';
import 'package:stacked/stacked.dart';

import 'top_model.dart';

class Top extends StackedView<TopModel> {
  Top({super.key, required this.textdown});
  String textdown;

  @override
  Widget builder(
    BuildContext context,
    TopModel viewModel,
    Widget? child,
  ) {
    return Container(
      width: screenWidth(context),
      padding: const EdgeInsets.fromLTRB(10, 15, 15, 0),
      margin: const EdgeInsets.fromLTRB(15, 15, 15, 0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Icon(Icons.login),
          horizontalSpaceMedium,
          text_helper(
                  data: textdown,
                  font: roboto,
                  color: kcPrimaryColorDark,
                  textAlign: TextAlign.start,
                  bold: true,
                  size: fontSize16)
              .animate(delay: 600.milliseconds)
              .fade()
              .animate(delay: 300.milliseconds)
              .fade(),
        ],
      ),
    );
  }

  @override
  TopModel viewModelBuilder(
    BuildContext context,
  ) =>
      TopModel();
}
