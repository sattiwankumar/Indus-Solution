import 'package:stacked/stacked.dart';

class TopModel extends BaseViewModel {}
