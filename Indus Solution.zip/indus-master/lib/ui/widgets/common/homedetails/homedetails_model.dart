import 'package:indus/ui/views/orders/orders_view.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../../app/app.locator.dart';
import '../../../../app/app.router.dart';
import '../../../../services/sharedpref_service.dart';

class HomedetailsModel extends BaseViewModel {
  final sharedpref = locator<SharedprefService>();
  final _navigationService = locator<NavigationService>();

  void order() {
    _navigationService.navigateWithTransition(
        OrdersView(
          check: true,
        ),
        routeName: Routes.ordersView,
        transitionStyle: Transition.rightToLeft);
  }

  void back() {
    _navigationService.back();
  }

  List<String> data = ["assets/pro1.jpg", "assets/pro2.jpg", "assets/pro3.jpg"];
}
