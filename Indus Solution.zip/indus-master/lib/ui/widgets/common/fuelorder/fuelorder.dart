import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:indus/ui/common/app_strings.dart';
import 'package:indus/ui/common/uihelper/button_helper.dart';
import 'package:indus/ui/common/uihelper/text_helper.dart';
import 'package:indus/ui/common/uihelper/text_veiw_helper.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/ui_helpers.dart';
import 'fuelorder_model.dart';

class Fuelorder extends StackedView<FuelorderModel> {
  Fuelorder({super.key, required this.type});
  String type;

  @override
  Widget builder(
    BuildContext context,
    FuelorderModel viewModel,
    Widget? child,
  ) {
    return Container(
      width: screenWidth(context),
      height: screenHeightCustom(context, 0.8),
      color: white,
      padding: const EdgeInsets.all(10),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              text_helper(
                data: "Order Now",
                font: poppins,
                color: kcDarkGreyColor,
                size: fontSize16,
                bold: true,
              ),
              InkWell(
                onTap: () => viewModel.back(),
                child: Container(
                  padding: const EdgeInsets.all(5),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(50),
                      border: Border.all(width: 1, color: kcDarkGreyColor)),
                  child: const Icon(Icons.close),
                ),
              )
            ],
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
              child: Column(
                children: [
                  type == 'mechanics' || type == 'Electrician'
                      ? text_view_helper(
                          hint: "Description",
                          showicon: true,
                          icon: const Icon(Icons.design_services),
                          formatter: [
                            FilteringTextInputFormatter.allow(getRegExpstring())
                          ],
                          controller: viewModel.quantity)
                      : text_view_helper(
                          hint: "Quantity in liters",
                          showicon: true,
                          icon: const Icon(Icons.production_quantity_limits),
                          textInputType: TextInputType.phone,
                          formatter: [
                            FilteringTextInputFormatter.allow(getRegExpint())
                          ],
                          controller: viewModel.quantity),
                  text_view_helper(
                      hint: "Some additional notes",
                      showicon: true,
                      icon: const Icon(Icons.description),
                      controller: viewModel.additional),
                  text_view_helper(
                      hint: "Add location",
                      showicon: true,
                      icon: const Icon(Icons.add_location_outlined),
                      controller: viewModel.location),
                  InkWell(
                    onTap: () => viewModel.addloc(),
                    child: text_helper(
                        data: "Choose from current location",
                        font: poppins,
                        color: kcPrimaryColorDark,
                        size: fontSize14),
                  ),
                  type == 'mechanics'
                      ? Container(
                          width: screenWidth(context),
                          margin: const EdgeInsets.all(5),
                          padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
                          decoration: BoxDecoration(
                              boxShadow: [
                                BoxShadow(
                                    offset: const Offset(2, 2),
                                    blurRadius: 1,
                                    spreadRadius: 1,
                                    color: getColorWithOpacity(
                                        kcPrimaryColorDark, 0.2))
                              ],
                              borderRadius: BorderRadius.circular(10),
                              color: white),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  const Icon(
                                    Icons.merge_type,
                                    color: kcDarkGreyColor,
                                  ),
                                  horizontalSpaceTiny,
                                  text_helper(
                                      data: "Mechanics Type",
                                      font: poppins,
                                      color: kcDarkGreyColor,
                                      size: fontSize12),
                                ],
                              ),
                              DropdownButton<String>(
                                value: viewModel.ms,
                                underline: const SizedBox.shrink(),
                                onChanged: (String? newValue) {
                                  viewModel.ms = newValue!;
                                  viewModel.notifyListeners();
                                },
                                items: viewModel.m
                                    .map<DropdownMenuItem<String>>(
                                        (String value) {
                                  return DropdownMenuItem<String>(
                                    value: value,
                                    child: text_helper(
                                        data: value,
                                        font: poppins,
                                        color: kcDarkGreyColor,
                                        size: fontSize12),
                                  );
                                }).toList(),
                              ),
                            ],
                          ),
                        )
                      : const SizedBox.shrink(),
                ],
              ),
            ),
          ),
          button_helper(
              onpress: () => viewModel.addorder(context, type),
              color: kcPrimaryColorDark,
              width: screenWidthCustom(context, 0.4),
              child: text_helper(
                  data: "Add",
                  font: poppins,
                  color: white,
                  bold: true,
                  size: fontSize14))
        ],
      ),
    );
  }

  @override
  void onViewModelReady(FuelorderModel viewModel) {
    if (type == 'Electrician') {
      viewModel.ms == "Electrician";
    }
    super.onViewModelReady(viewModel);
  }

  @override
  FuelorderModel viewModelBuilder(
    BuildContext context,
  ) =>
      FuelorderModel();
}
