import 'package:flutter/cupertino.dart';
import 'package:geolocator/geolocator.dart';
import 'package:indus/ui/common/apihelpers/apihelper.dart';
import 'package:indus/ui/common/uihelper/snakbar_helper.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../../app/app.locator.dart';
import '../../../../services/sharedpref_service.dart';
import '../../../common/apihelpers/firebsaeuploadhelper.dart';

class FuelorderModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final sharedpref = locator<SharedprefService>();

  TextEditingController quantity = TextEditingController();
  TextEditingController location = TextEditingController();
  TextEditingController additional = TextEditingController();

  Future<void> addloc() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }
    Position p = await Geolocator.getCurrentPosition();
    location.text = "lat : ${p.latitude}  Lon : ${p.longitude}";
    notifyListeners();
  }

  Future<void> addorder(BuildContext context, String type) async {
    if (quantity.text.isEmpty || location.text.isEmpty) {
      show_snackbar(context, "Fill all fields");
    } else {
      displayprogress(context);
      if (type == 'mechanics') {
        type = "$type $ms";
      }
      bool check = await ApiHelper.registerorder(
          sharedpref.readString('number'),
          quantity.text,
          additional.text,
          type,
          location.text,
          DateTime.now().toString(),
          "new",
          "",
          context);
      FirebaseHelper.sendnotificationto(sharedpref.readString("deviceid"),
          "Order", "Order Sucessfully Placed");
      if (check) {
        hideprogress(context);
        back();
      } else {
        hideprogress(context);
      }
    }
  }

  void back() {
    _navigationService.back();
  }

  String ms = 'Motor cycle';
  List<String> m = ['Motor cycle', 'Car', "Machine", "Generator", "Other"];
}
