import 'package:flutter/cupertino.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:indus/ui/common/apihelpers/apihelper.dart';
import 'package:indus/ui/common/uihelper/snakbar_helper.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../../app/app.locator.dart';
import '../../../../services/sharedpref_service.dart';
import '../../../common/apihelpers/firebsaeuploadhelper.dart';

class FuelorderModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final sharedpref = locator<SharedprefService>();

  TextEditingController quantity = TextEditingController();
  TextEditingController location = TextEditingController();
  TextEditingController additional = TextEditingController();

  Future<void> addloc() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }
    Position p = await Geolocator.getCurrentPosition();
    location.text = "lat : ${p.latitude}  Lon : ${p.longitude}";
    setloc = true;
    notifyListeners();
  }

  bool setloc = false;

  Future<String> getLatLongFromAddress(String address) async {
    try {
      List<Location> locations = await locationFromAddress(address);
      double latitude = locations.first.latitude;
      double longitude = locations.first.longitude;

      return "lat : $latitude  Lon : $longitude";
    } catch (e) {
      return "lat : 32.45577  Lon :75.2514";
    }
  }


  Future<void> addorder(BuildContext context, String type) async {
    if (quantity.text.isEmpty || location.text.isEmpty) {
      show_snackbar(context, "Fill all fields");
    } else {
      displayprogress(context);
      Map wdata = await ApiHelper.getwallet(sharedpref.readString('number'));

      String number = "0000-0000000";
      int price = 0;
      if (type == 'mechanics' || type == "Electrician") {
        price = 500;
      } else {
        price = 280 * int.parse(quantity.text.toString());
      }

      if (wdata['status']) {
        Map rdata = await ApiHelper.getwallet(number);
        bool ru = await ApiHelper.updatewallet(
            number,
            rdata['rest']['notpay'],
            rdata['rest']['paid'],
            "${int.parse(rdata['rest']['topup']) + price}",
            price.toString(),
            context);
        if (ru) {
          wdata = await ApiHelper.getwallet(sharedpref.readString('number'));
          bool uw = await ApiHelper.updatewallet(
              sharedpref.readString('number'),
              wdata['rest']['notpay'],
              "${int.parse(wdata['rest']['paid']) + price}",
              wdata['rest']['topup'],
              price.toString(),
              context);
          if (uw) {
            if (type == 'mechanics') {
              type = "$type $ms";
            }

            if (!setloc){
              location.text = await getLatLongFromAddress(location.text);
            }

            bool check = await ApiHelper.registerorder(
                sharedpref.readString('number'),
                quantity.text,
                additional.text,
                type,
                location.text,
                DateTime.now().toString(),
                "new",
                "",
                context);
            FirebaseHelper.sendnotificationto(sharedpref.readString("deviceid"),
                "Order", "Order Sucessfully Placed");
            if (check) {
              hideprogress(context);
              back();
            } else {
              hideprogress(context);
            }
          }
        }
      }
    }
  }

  void back() {
    _navigationService.back();
  }

  String ms = 'Motor cycle';
  List<String> m = ['Motor cycle', 'Car', "Machine", "Generator", "Other"];
}
