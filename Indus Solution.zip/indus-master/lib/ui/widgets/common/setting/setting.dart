import 'package:cached_network_image/cached_network_image.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:indus/ui/common/app_colors.dart';
import 'package:indus/ui/common/app_strings.dart';
import 'package:indus/ui/common/ui_helpers.dart';
import 'package:indus/ui/common/uihelper/button_helper.dart';
import 'package:indus/ui/common/uihelper/text_helper.dart';
import 'package:stacked/stacked.dart';

import 'setting_model.dart';

class Setting extends StackedView<SettingModel> {
  const Setting({super.key});

  @override
  Widget builder(
    BuildContext context,
    SettingModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: white,
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: screenWidth(context),
              padding: const EdgeInsets.all(15),
              child: Column(
                children: [
                  InkWell(
                    child: Container(
                      width: screenWidthCustom(context, 0.25),
                      height: screenWidthCustom(context, 0.25),
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                          color: white,
                          borderRadius: BorderRadius.circular(50),
                          border: Border.all(
                              width: 3,
                              color: kcPrimaryColorDark,
                              strokeAlign: BorderSide.strokeAlignOutside)),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(50),
                        child: CachedNetworkImage(
                          imageUrl: viewModel.sharedpref.readString('img'),
                          imageBuilder: (context, imageProvider) => Container(
                            width: screenWidthCustom(context, 0.19),
                            height: screenWidthCustom(context, 0.19),
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: imageProvider,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          placeholder: (context, url) =>
                              const CircularProgressIndicator(),
                          errorWidget: (context, url, error) =>
                              const Icon(Icons.error),
                        ),
                      ),
                    ),
                  ),
                  verticalSpaceSmall,
                  text_helper(
                      data: 'welcome',
                      font: poppins,
                      color: kcPrimaryColorDark,
                      size: fontSize12),
                  text_helper(
                      data: viewModel.sharedpref.readString('name'),
                      bold: true,
                      font: poppins,
                      color: kcPrimaryColorDark,
                      size: fontSize16)
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 5, 10, 0),
              child: text_helper(
                data: "Details",
                font: poppins,
                color: kcPrimaryColorDark,
                size: fontSize12,
                bold: true,
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
              child: DottedBorder(
                borderType: BorderType.RRect,
                radius: const Radius.circular(10),
                padding: const EdgeInsets.all(10),
                dashPattern: const [8, 4],
                child: SizedBox(
                  width: screenWidth(context),
                  child: Column(
                    children: [
                      showrow("number",
                          viewModel.sharedpref.readString('number'), true),
                      showrow("address",
                          viewModel.sharedpref.readString('address'), true),
                      showrow(
                          "dob", viewModel.sharedpref.readString('dob'), true),
                      showrow("cnic", viewModel.sharedpref.readString('cnic'),
                          false),
                    ],
                  ),
                ), // Dash pattern for the dotted border
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: button_helper(
                  onpress: () => viewModel.logout(),
                  color: kcPrimaryColorDark,
                  width: screenWidthCustom(context, 0.8),
                  child: text_helper(
                      data: "Logout",
                      font: poppins,
                      color: white,
                      bold: true,
                      size: fontSize14)),
            )
          ],
        ),
      ),
    );
  }

  Widget showrow(String title, String des, bool d) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              text_helper(
                  data: title,
                  font: poppins,
                  color: kcLightGrey,
                  size: fontSize12),
              text_helper(
                  data: des,
                  font: poppins,
                  color: kcPrimaryColor,
                  size: fontSize12)
            ],
          ),
        ),
        d
            ? const Divider(
                height: 3,
              )
            : const SizedBox.shrink(),
      ],
    );
  }

  @override
  SettingModel viewModelBuilder(
    BuildContext context,
  ) =>
      SettingModel();
}
