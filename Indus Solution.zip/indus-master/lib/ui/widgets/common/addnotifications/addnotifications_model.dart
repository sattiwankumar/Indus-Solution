import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:image_picker/image_picker.dart';
import 'package:indus/ui/common/apihelpers/apihelper.dart';
import 'package:indus/ui/common/apihelpers/firebsaeuploadhelper.dart';
import 'package:indus/ui/common/uihelper/snakbar_helper.dart';
import 'package:stacked/stacked.dart';

import '../../../../app/app.locator.dart';
import '../../../../services/sharedpref_service.dart';

class AddnotificationsModel extends BaseViewModel {
  final _sharedpref = locator<SharedprefService>();

  TextEditingController name = TextEditingController();
  TextEditingController des = TextEditingController();

  File? image;
  Future<void> pic() async {
    final pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      image = File(pickedFile.path);
      notifyListeners();
    }
  }

  Future<void> addnotifications(BuildContext context) async {
    if (name.text.isEmpty && des.text.isEmpty) {
      show_snackbar(context, "fill all fields");
    } else if (image == null) {
      show_snackbar(context, "select image");
    } else {
      displayprogress(context);
      String url = await FirebaseHelper.uploadFile(
          image, _sharedpref.readString("number"));
      bool c = await ApiHelper.registernotification(
          name.text, des.text, url, context);
      Navigator.pop(context);
    }
  }
}
