import 'package:flutter/material.dart';
import 'package:indus/ui/common/ui_helpers.dart';
import 'package:indus/ui/common/uihelper/button_helper.dart';
import 'package:indus/ui/common/uihelper/text_veiw_helper.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/app_strings.dart';
import '../../../common/uihelper/text_helper.dart';
import 'addnotifications_model.dart';

class Addnotifications extends StackedView<AddnotificationsModel> {
  const Addnotifications({super.key});

  @override
  Widget builder(
    BuildContext context,
    AddnotificationsModel viewModel,
    Widget? child,
  ) {
    return Container(
      width: screenWidth(context),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: white,
      ),
      child: ListView(
        shrinkWrap: true,
        children: [
          verticalSpaceSmall,
          text_helper(
              data: "Add Notifications",
              font: poppins,
              color: kcDarkGreyColor,
              size: fontSize16,
              bold: true),
          verticalSpaceSmall,
          InkWell(
            onTap: () => viewModel.pic(),
            child: viewModel.image == null
                ? Image.asset("assets/notifications.png")
                : Image.file(viewModel.image!),
          ),
          text_helper(
              data: "Click above to select image",
              font: poppins,
              color: Colors.red,
              size: fontSize10),
          verticalSpaceSmall,
          text_view_helper(
              hint: "notification title",
              controller: viewModel.name,
              showicon: true,
              icon: const Icon(Icons.title)),
          text_view_helper(
              hint: "notification Description",
              controller: viewModel.des,
              showicon: true,
              icon: const Icon(Icons.description)),
          verticalSpaceSmall,
          button_helper(
              onpress: () => viewModel.addnotifications(context),
              color: kcPrimaryColor,
              width: screenWidth(context),
              child: text_helper(
                  data: "Add",
                  font: poppins,
                  color: white,
                  size: fontSize16,
                  bold: true))
        ],
      ),
    );
  }

  @override
  AddnotificationsModel viewModelBuilder(
    BuildContext context,
  ) =>
      AddnotificationsModel();
}
