import 'package:flutter/material.dart';
import 'package:indus/ui/common/app_colors.dart';
import 'package:indus/ui/common/app_strings.dart';
import 'package:indus/ui/common/ui_helpers.dart';
import 'package:indus/ui/common/uihelper/text_helper.dart';
import 'package:indus/ui/widgets/common/top/top.dart';
import 'package:indus/ui/widgets/common/top2/top2.dart';
import 'package:stacked/stacked.dart';

import '../../../common/apihelpers/apihelper.dart';
import '../../../common/uihelper/snakbar_helper.dart';
import 'faqs_model.dart';

class Faqs extends StackedView<FaqsModel> {
  const Faqs({super.key});

  @override
  Widget builder(
    BuildContext context,
    FaqsModel viewModel,
    Widget? child,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        verticalSpaceSmall,
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: text_helper(
              data: "Frequently Asked Questions",
              font: poppins,
              color: kcDarkGreyColor,
              size: fontSize16,
              bold: true),
        ),
        verticalSpaceSmall,
        Expanded(
          child: FutureBuilder(
            future: ApiHelper.allfaqs(context),
            builder: (BuildContext context, AsyncSnapshot snapshot) {
              if (snapshot.hasData) {
                return ListView.builder(
                  itemCount: snapshot.data.length,
                  itemBuilder: (BuildContext context, int index) {
                    return Container(
                        width: screenWidth(context),
                        margin: const EdgeInsets.only(
                            left: 10, right: 10, bottom: 10),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius:
                              const BorderRadius.all(Radius.circular(10)),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.deepPurple.withOpacity(0.1),
                              spreadRadius: 1,
                              blurRadius: 1,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8.0),
                                  child: text_helper(
                                    data: snapshot.data[index]['title'],
                                    font: poppins,
                                    color: kcDarkGreyColor,
                                    size: fontSize16,
                                    textAlign: TextAlign.start,
                                    bold: true,
                                  )),
                              Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8.0),
                                  child: text_helper(
                                      data: snapshot.data[index]['ans'],
                                      font: poppins,
                                      color: kcPrimaryColor,
                                      textAlign: TextAlign.start,
                                      size: fontSize12)),
                            ]));
                  },
                );
              } else if (snapshot.hasError) {
                return const Icon(
                  Icons.error,
                );
              } else {
                return displaysimpleprogress(context);
              }
            },
          ),
        )
      ],
    );
  }

  @override
  FaqsModel viewModelBuilder(
    BuildContext context,
  ) =>
      FaqsModel();
}
