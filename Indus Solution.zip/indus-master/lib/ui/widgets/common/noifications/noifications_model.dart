import 'package:stacked/stacked.dart';

class NoificationsModel extends BaseViewModel {}
