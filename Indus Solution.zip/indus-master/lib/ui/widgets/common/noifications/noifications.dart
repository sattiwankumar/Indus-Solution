import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../../common/apihelpers/apihelper.dart';
import '../../../common/app_colors.dart';
import '../../../common/app_strings.dart';
import '../../../common/ui_helpers.dart';
import '../../../common/uihelper/snakbar_helper.dart';
import '../../../common/uihelper/text_helper.dart';
import 'noifications_model.dart';

class Noifications extends StackedView<NoificationsModel> {
  const Noifications({super.key});

  @override
  Widget builder(
    BuildContext context,
    NoificationsModel viewModel,
    Widget? child,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        verticalSpaceSmall,
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: text_helper(
              data: "All Notifications",
              font: poppins,
              color: kcDarkGreyColor,
              size: fontSize16,
              bold: true),
        ),
        verticalSpaceSmall,
        Expanded(
          child: FutureBuilder(
            future: ApiHelper.allnotification(context),
            builder: (BuildContext context, AsyncSnapshot snapshot) {
              if (snapshot.hasData) {
                return ListView.builder(
                  itemCount: snapshot.data.length,
                  itemBuilder: (BuildContext context, int index) {
                    return Container(
                        width: screenWidth(context),
                        margin: const EdgeInsets.only(
                            left: 10, right: 10, bottom: 10),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius:
                              const BorderRadius.all(Radius.circular(10)),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.deepPurple.withOpacity(0.1),
                              spreadRadius: 1,
                              blurRadius: 1,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            CachedNetworkImage(
                              imageUrl: snapshot.data[index]['url'],
                              imageBuilder: (context, imageProvider) =>
                                  ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Container(
                                  width: screenWidthCustom(context, 0.15),
                                  height: screenWidthCustom(context, 0.15),
                                  decoration: BoxDecoration(
                                    image: DecorationImage(
                                      image: imageProvider,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                              placeholder: (context, url) =>
                                  displaysimpleprogress(context),
                              errorWidget: (context, url, error) => const Icon(
                                Icons.error,
                                color: kcDarkGreyColor,
                              ),
                            ),
                            horizontalSpaceTiny,
                            Expanded(
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 8.0),
                                        child: text_helper(
                                          data: snapshot.data[index]['title'],
                                          font: poppins,
                                          color: kcPrimaryColor,
                                          size: fontSize16,
                                          bold: true,
                                        )),
                                    Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 8.0),
                                        child: text_helper(
                                            data: snapshot.data[index]['ans'],
                                            font: poppins,
                                            color: kcDarkGreyColor,
                                            size: fontSize14)),
                                    Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 8.0),
                                        child: text_helper(
                                            data: snapshot.data[index]['time']
                                                .toString()
                                                .substring(0, 16),
                                            font: poppins,
                                            color: kcDarkGreyColor,
                                            size: fontSize10)),
                                  ]),
                            ),
                          ],
                        ));
                  },
                );
              } else if (snapshot.hasError) {
                return const Icon(
                  Icons.error,
                );
              } else {
                return displaysimpleprogress(context);
              }
            },
          ),
        )
      ],
    );
  }

  @override
  NoificationsModel viewModelBuilder(
    BuildContext context,
  ) =>
      NoificationsModel();
}
