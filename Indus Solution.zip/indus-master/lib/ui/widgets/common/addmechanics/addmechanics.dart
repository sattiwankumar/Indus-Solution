import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:indus/ui/common/app_colors.dart';
import 'package:indus/ui/common/uihelper/button_helper.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_strings.dart';
import '../../../common/ui_helpers.dart';
import '../../../common/uihelper/text_helper.dart';
import '../../../common/uihelper/text_veiw_helper.dart';
import 'addmechanics_model.dart';

class Addmechanics extends StackedView<AddmechanicsModel> {
  const Addmechanics({super.key});

  @override
  Widget builder(
    BuildContext context,
    AddmechanicsModel viewModel,
    Widget? child,
  ) {
    return Container(
      width: screenWidth(context),
      height: screenHeightCustom(context, 0.8),
      padding: const EdgeInsets.all(10),
      color: white,
      child: SingleChildScrollView(
        child: Column(
          children: [
            verticalSpaceSmall,
            Container(
              width: 100,
              height: 5,
              decoration: BoxDecoration(
                  color: kcPrimaryColorDark,
                  borderRadius: BorderRadius.circular(10)),
            ),
            verticalSpaceSmall,
            text_view_helper(
              hint: "Enter name",
              controller: viewModel.name,
              showicon: true,
            ).animate(delay: 700.milliseconds).fade().moveY(begin: 50, end: 0),
            text_view_helper(
              hint: "Enter number",
              controller: viewModel.number,
              showicon: true,
              icon: const Icon(Icons.call),
              maxlength: 11,
              formatter: [FilteringTextInputFormatter.allow(getRegExpint())],
              textInputType: TextInputType.phone,
            ).animate(delay: 900.milliseconds).fade().moveY(begin: 50, end: 0),
            text_view_helper(
              hint: "Enter cnic",
              controller: viewModel.cnic,
              showicon: true,
              icon: const Icon(Icons.dock),
              maxlength: 13,
              formatter: [FilteringTextInputFormatter.allow(getRegExpint())],
              textInputType: TextInputType.phone,
            ).animate(delay: 1100.milliseconds).fade().moveY(begin: 50, end: 0),
            text_view_helper(
                    hint: "Enter mechanics shop address",
                    controller: viewModel.address,
                    showicon: true,
                    icon: const Icon(Icons.home))
                .animate(delay: 1300.milliseconds)
                .fade()
                .moveY(begin: 50, end: 0),
            Container(
              width: screenWidth(context),
              margin: const EdgeInsets.all(5),
              padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
              decoration: BoxDecoration(boxShadow: [
                BoxShadow(
                    offset: const Offset(2, 2),
                    blurRadius: 1,
                    spreadRadius: 1,
                    color: getColorWithOpacity(kcPrimaryColorDark, 0.2))
              ], borderRadius: BorderRadius.circular(10), color: white),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      const Icon(
                        Icons.merge_type,
                        color: kcDarkGreyColor,
                      ),
                      horizontalSpaceTiny,
                      text_helper(
                          data: "Mechanics Type",
                          font: poppins,
                          color: kcDarkGreyColor,
                          size: fontSize12),
                    ],
                  ),
                  DropdownButton<String>(
                    value: viewModel.ms,
                    underline: const SizedBox.shrink(),
                    onChanged: (String? newValue) {
                      viewModel.ms = newValue!;
                      viewModel.notifyListeners();
                    },
                    items: viewModel.m
                        .map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: text_helper(
                            data: value,
                            font: poppins,
                            color: kcDarkGreyColor,
                            size: fontSize12),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ).animate(delay: 1500.milliseconds).fade().moveY(begin: 50, end: 0),
            Padding(
              padding: const EdgeInsets.all(5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  pic(context, viewModel, "profile"),
                  pic(context, viewModel, "cnic front"),
                  pic(context, viewModel, "cnic back"),
                ],
              )
                  .animate(delay: 1700.milliseconds)
                  .fade()
                  .moveY(begin: 50, end: 0),
            ),
            button_helper(
                    onpress: () => viewModel.add(context),
                    color: kcPrimaryColorDark,
                    width: screenWidthCustom(context, 0.4),
                    child: text_helper(
                      data: "Add",
                      font: poppins,
                      color: white,
                      size: fontSize16,
                      bold: true,
                    ))
                .animate(delay: 1900.milliseconds)
                .fade()
                .moveY(begin: 50, end: 0),
          ],
        ),
      ),
    );
  }

  Widget pic(BuildContext context, AddmechanicsModel viewModal, String check) {
    return InkWell(
      onTap: () => viewModal.pic(check),
      child: Container(
        width: screenWidthCustom(context, 0.29),
        height: screenWidthCustom(context, 0.3),
        decoration: BoxDecoration(boxShadow: [
          BoxShadow(
              offset: const Offset(2, 2),
              blurRadius: 1,
              spreadRadius: 1,
              color: getColorWithOpacity(kcPrimaryColorDark, 0.2))
        ], borderRadius: BorderRadius.circular(10), color: white),
        child: DottedBorder(
          borderType: BorderType.RRect,
          radius: const Radius.circular(10),
          padding: const EdgeInsets.all(2),
          dashPattern: const [8, 4],
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              if (check == 'profile')
                viewModal.profile == null
                    ? Center(
                        child: Image.asset(
                          'assets/profile.png',
                          width: screenWidthCustom(context, 0.1),
                          height: screenWidthCustom(context, 0.1),
                        ),
                      )
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.file(
                          viewModal.profile!,
                          width: screenWidthCustom(context, 0.29),
                          height: screenWidthCustom(context, 0.28),
                          fit: BoxFit.cover,
                        ),
                      )
              else if (check == 'cnic front')
                viewModal.cnicfront == null
                    ? Center(
                        child: Image.asset(
                          'assets/cnicfront.png',
                          width: screenWidthCustom(context, 0.15),
                          height: screenWidthCustom(context, 0.15),
                        ),
                      )
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.file(
                          viewModal.cnicfront!,
                          width: screenWidthCustom(context, 0.29),
                          height: screenWidthCustom(context, 0.28),
                          fit: BoxFit.cover,
                        ),
                      )
              else
                viewModal.cnicback == null
                    ? Center(
                        child: Image.asset(
                          'assets/cnicback.png',
                          width: screenWidthCustom(context, 0.2),
                          height: screenWidthCustom(context, 0.2),
                        ),
                      )
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.file(
                          viewModal.cnicback!,
                          width: screenWidthCustom(context, 0.29),
                          height: screenWidthCustom(context, 0.28),
                          fit: BoxFit.cover,
                        ),
                      )
            ],
          ), // Dash pattern for the dotted border
        ),
      ),
    );
  }

  @override
  AddmechanicsModel viewModelBuilder(
    BuildContext context,
  ) =>
      AddmechanicsModel();
}
