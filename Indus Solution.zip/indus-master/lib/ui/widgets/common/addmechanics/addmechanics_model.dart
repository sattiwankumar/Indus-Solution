import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter_masked_text2/flutter_masked_text2.dart';
import 'package:image_picker/image_picker.dart';
import 'package:indus/ui/common/apihelpers/apihelper.dart';
import 'package:indus/ui/common/apihelpers/firebsaeuploadhelper.dart';
import 'package:indus/ui/common/uihelper/snakbar_helper.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../../app/app.locator.dart';
import '../../../../services/sharedpref_service.dart';

class AddmechanicsModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final _sharedpref = locator<SharedprefService>();

  TextEditingController name = TextEditingController();
  TextEditingController number = MaskedTextController(mask: '0000-0000000');
  TextEditingController cnic = MaskedTextController(mask: '00000-0000000-0');
  TextEditingController address = TextEditingController();

  Future<void> add(BuildContext context) async {
    if (name.text.isEmpty ||
        number.text.isEmpty ||
        cnic.text.isEmpty ||
        address.text.isEmpty ||
        profile == null ||
        cnicfront == null ||
        cnicback == null) {
      show_snackbar(context, "Fill all fields");
    } else {
      displayprogress(context);

      String urlp = await FirebaseHelper.uploadFile(
          profile, _sharedpref.readString('number'));
      String urlcf = await FirebaseHelper.uploadFile(
          cnicfront, _sharedpref.readString('number'));
      String urlcb = await FirebaseHelper.uploadFile(
          cnicback, _sharedpref.readString('number'));

      bool check = await ApiHelper.registermechanics(name.text, number.text,
          cnic.text, address.text, ms, urlp, urlcf, urlcb, 'free', context);
      hideprogress(context);
      if (check) {
        _navigationService.back();
      }
    }
  }

  File? profile;
  File? cnicback;
  File? cnicfront;
  Future<void> pic(String check) async {
    final pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      if (check == 'profile') {
        profile = File(pickedFile.path);
      } else if (check == 'cnic front') {
        cnicfront = File(pickedFile.path);
      } else {
        cnicback = File(pickedFile.path);
      }
      notifyListeners();
    }
  }

  String ms = 'Motor cycle';
  List<String> m = ['Motor cycle', 'Car', "Electrician", "Machine", "Generator", "Other"];
}
