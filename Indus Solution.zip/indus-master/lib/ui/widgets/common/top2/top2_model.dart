import 'package:indus/app/app.locator.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

class Top2Model extends BaseViewModel {
  final _nav = locator<NavigationService>();

  void back() {
    _nav.back();
  }
}
