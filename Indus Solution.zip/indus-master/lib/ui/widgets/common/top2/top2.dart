import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/app_strings.dart';
import '../../../common/ui_helpers.dart';
import '../../../common/uihelper/text_helper.dart';
import 'top2_model.dart';

class Top2 extends StackedView<Top2Model> {
  Top2({super.key, required this.txt});
  String txt;

  @override
  Widget builder(
    BuildContext context,
    Top2Model viewModel,
    Widget? child,
  ) {
    return Container(
      width: screenWidth(context),
      padding: const EdgeInsets.fromLTRB(15, 10, 0, 5),
      margin: const EdgeInsets.fromLTRB(15, 10, 0, 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          InkWell(
              onTap: () => viewModel.back(),
              child: Container(
                  padding: const EdgeInsets.all(2),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(50),
                      border: Border.all(width: 3, color: kcPrimaryColorDark)),
                  child: const Icon(
                    Icons.arrow_back,
                    color: kcPrimaryColorDark,
                  ))),
          horizontalSpaceMedium,
          text_helper(
                  data: txt,
                  font: roboto,
                  color: kcPrimaryColorDark,
                  textAlign: TextAlign.start,
                  bold: true,
                  size: fontSize16)
              .animate(delay: 600.milliseconds)
              .fade()
              .animate(delay: 300.milliseconds)
              .fade(),
        ],
      ),
    );
  }

  @override
  Top2Model viewModelBuilder(
    BuildContext context,
  ) =>
      Top2Model();
}
