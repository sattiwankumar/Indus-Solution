import 'package:indus/ui/bottom_sheets/notice/notice_sheet.dart';
import 'package:indus/ui/dialogs/info_alert/info_alert_dialog.dart';
import 'package:indus/ui/views/home/home_view.dart';
import 'package:indus/ui/views/startup/startup_view.dart';
import 'package:stacked/stacked_annotations.dart';
import 'package:stacked_services/stacked_services.dart';
import 'package:indus/services/fire_service.dart';
import 'package:indus/services/sharedpref_service.dart';
import 'package:indus/ui/views/login/login_view.dart';
import 'package:indus/ui/views/signup/signup_view.dart';
import 'package:indus/ui/views/otp/otp_view.dart';
import 'package:indus/ui/views/pass/pass_view.dart';
import 'package:indus/ui/views/admin/admin_view.dart';
import 'package:indus/ui/views/mechanics/mechanics_view.dart';
import 'package:indus/ui/views/orders/orders_view.dart';
import 'package:indus/ui/views/complaints/complaints_view.dart';
// @stacked-import

@StackedApp(
  routes: [
    MaterialRoute(page: HomeView),
    MaterialRoute(page: StartupView),
    MaterialRoute(page: LoginView),
    MaterialRoute(page: SignupView),
    MaterialRoute(page: OtpView),
    MaterialRoute(page: PassView),
    MaterialRoute(page: AdminView),
    MaterialRoute(page: MechanicsView),
    MaterialRoute(page: OrdersView),
    MaterialRoute(page: ComplaintsView),
// @stacked-route
  ],
  dependencies: [
    LazySingleton(classType: BottomSheetService),
    LazySingleton(classType: DialogService),
    LazySingleton(classType: NavigationService),
    LazySingleton(classType: FireService),
    LazySingleton(classType: SharedprefService),
// @stacked-service
  ],
  bottomsheets: [
    StackedBottomsheet(classType: NoticeSheet),
    // @stacked-bottom-sheet
  ],
  dialogs: [
    StackedDialog(classType: InfoAlertDialog),
    // @stacked-dialog
  ],
)
class App {}
