const orderService = require('../services/order.service');

exports.registerorder = async(req,res,next)=>{
    try{
        const {number,quantity,des,loc,datetime,type,status,mechanicsid} = req.body;
        const response = await orderService.registerorder(number,quantity,des,loc,
            datetime,type,status,mechanicsid);
        res.json({status:true,sucess:"order registered Sucessfully"});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller register"});
    }
}

exports.getorder = async(req,res,next)=>{
    try{
        const order = await orderService.getorder();
        res.status(200).json({order:order});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller mood"});
    }
}

exports.updatestatus = async(req,res,next)=>{
    try{
        const {number,status,mechanicsid} = req.body;
        const response = await orderService.updatestatus(number,status,mechanicsid);
        res.json({status:true,sucess:"updated Sucessfully"});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller register"});
    }
}

exports.getorderbynum = async(req,res,next)=>{
    try{
        const {number} = req.body;
        const order = await orderService.getorderbynum(number);
        res.status(200).json({order:order});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller mood"});
    }
}