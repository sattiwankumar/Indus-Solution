const adminService = require('../services/admin.service');

exports.registeradmin = async(req,res,next)=>{
    try{
        const {num,did} = req.body;
        id = await adminService.getid();
        if(id===null){
            await adminService.registeradmin(num,did);
        } else{
            await adminService.updateadmin(num,did);
        }
        id = await adminService.getid();
        res.json({status:true,sucess:"ok",res:id});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller register"});
    }
}