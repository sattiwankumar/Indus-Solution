const mechanicsService = require('../services/mechanics.service');

exports.registermechanics = async(req,res,next)=>{
    try{
        const {name,number,cnic,address,type,profile,cnicf,cnicb,status} = req.body;
        const response = await mechanicsService.registermechanics(name,number,cnic,address,type,
            profile,cnicf,cnicb,status);
        res.json({status:true,sucess:"mechanic registered Sucessfully"});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller register"});
    }
}

exports.updatemechanics = async(req,res,next)=>{
    try{
        const {number,status} = req.body;
        const response = await mechanicsService.updatemechanics(number,status);
        res.json({status:true,sucess:"updated Sucessfully"});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller register"});
    }
}

exports.getmechanics = async(req,res,next)=>{
    try{
        const order = await mechanicsService.getmechanics();
        res.status(200).json({order:order});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller mood"});
    }
}
