const UserService = require('../services/user.service');

exports.register = async(req,res,next)=>{
    try{
        const {number,name,cnic,pass,address,dob,deviceid,img} = req.body;
        const user = await UserService.checkuser(number);
        if(user){
            res.json({status:false,sucess:"user already exist"});
        } else {
            const response = await UserService.registerUser(number,name,cnic,pass,address,dob,deviceid,img);
            res.json({status:true,sucess:"User registered Sucessfully"});
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller register"});
    }
}


exports.login = async(req,res,next)=>{
    try{
        const {number,pass,deviceid} = req.body;
        
        const user = await UserService.checkuser(number);
        if(!user){
            res.status(200).json({status:false,message:"no user found"});
        } else{

            const isMatch = await user.comparePassword(pass);
            if(isMatch == false){
                res.status(200).json({status:false,message:"invalid password"});
            } else{
                await UserService.updatedevice(user._id, deviceid);
                let tokenData = {number:user.number,name:user.name,cnic:user.cnic,address:user.address,dob:user.dob,
                    cat:user.cat,deviceid: deviceid,img:user.img};
                const token = await UserService.generateToken(tokenData,"learnandearn","1h")
                res.status(200).json({status:true,token:token,message:"login in sucessfully"});
            }
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}


exports.getoneuseronnumber = async(req,res,next)=>{
    try{
        const {number} = req.body;
        const user = await UserService.checkuser(number);
        res.status(200).json({status:false,message:"no user found",a:user});
    } catch (e){
        console.log(e)
        res.json({status:false,message:"server error controller login",a:{}});
    }
}

