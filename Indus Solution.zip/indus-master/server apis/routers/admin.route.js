const router = require('express').Router();
const adminController = require('../controller/admin.controller');

router.post("/registeradmin",adminController.registeradmin);

module.exports = router;