const router = require('express').Router();
const mechanicsController = require('../controller/mechanics.controller');

router.post("/registermechanics",mechanicsController.registermechanics);
router.post("/getmechanics",mechanicsController.getmechanics);
router.post("/updatemechanics",mechanicsController.updatemechanics);

module.exports = router;