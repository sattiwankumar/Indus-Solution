const router = require('express').Router();
const orderController = require('../controller/order.controller');

router.post("/registerorder",orderController.registerorder);
router.post("/getorder",orderController.getorder);
router.post("/getorderbynum",orderController.getorderbynum);
router.post("/updatestatus",orderController.updatestatus);

module.exports = router;