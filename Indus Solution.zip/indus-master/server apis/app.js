const express = require("express");
const bodyParser = require("body-parser")
const UserRoute = require("./routers/user.route");
const orderRoute = require("./routers/order.route");
const adminRoute = require("./routers/admin.route");
const mechanicsRoute = require("./routers/mechanics.router");
const faqsRoute = require("./routers/faqs.route");
const notificationRoute = require("./routers/notification.route");
const complaintRoute = require("./routers/complaint.route");
const walletRoute = require("./routers/wallet.route");

const app = express();
app.use(bodyParser.json());
app.use("/",UserRoute);
app.use("/",orderRoute);
app.use("/",adminRoute);
app.use("/",mechanicsRoute);
app.use("/",faqsRoute);
app.use("/",notificationRoute);
app.use("/",complaintRoute);
app.use("/",walletRoute);

module.exports = app;
