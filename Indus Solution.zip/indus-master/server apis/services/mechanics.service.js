const mechanicsmodel = require('../model/mechanics.modal');

class mechanicsService{
   static async registermechanics(name,number,cnic,address,type,profile,cnicf,cnicb,status,typerm){
        try{
            const m = new mechanicsmodel({name,number,cnic,address,type,profile,cnicf,cnicb,status,typerm});
            return await m.save();
        } catch(e){
            console.log(e)
        }
   }

   static async updatemechanics(number,status){
    try{
        return await mechanicsmodel.findByIdAndUpdate(number,{$set:{status:status}})
    } catch(e){
        console.log(e)
    }
    }

   static async getmechanics(){
    try{
        return await mechanicsmodel.find();
    } catch(e){
        console.log(e)
    }
   }

   static async getmechanicsid(id){
    try{
        return await mechanicsmodel.findById(id);
    } catch(e){
        console.log(e)
    }
   }

}

module.exports = mechanicsService;