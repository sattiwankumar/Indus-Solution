const adminmodel = require('../model/admin.modal');

class adminService{
   static async registeradmin(num,did){
        try{
            const adminid = new adminmodel({num,did});
            return await adminid.save();
        } catch(e){
            console.log(e)
        }
   }

   static async updateadmin(num,did){
    try{
        return await adminmodel.findOneAndUpdate({num:num},{$set:{did:did}})
    } catch(e){
        console.log(e)
    }
}

   static async getid(){
    try{
        return await adminmodel.findOne();
    } catch(e){
        console.log(e)
    }
   }

}

module.exports = adminService;