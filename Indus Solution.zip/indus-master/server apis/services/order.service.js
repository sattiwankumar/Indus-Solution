const ordermodel = require('../model/orders.modal');

class orderService{
   static async registerorder(number,quantity,des,loc,datetime,type,status,mechanicsid){
        try{
            const moodorder = new ordermodel({number,quantity,des,loc,
                datetime,type,status,mechanicsid});
            return await moodorder.save();
        } catch(e){
            console.log(e)
        }
   }

   static async getorder(){
    try{
        return await ordermodel.find().sort({ datetime: 1 });
    } catch(e){
        console.log(e)
    }
   }

   static async updatestatus(number,status,mechanicsid){
    try{
        return await ordermodel.findByIdAndUpdate(number,{$set:
            {status:status,mechanicsid:mechanicsid}})
    } catch(e){
        console.log(e)
    }
    }


   static async getorderbynum(number){
    try{
        return await ordermodel.find({number}).sort({ datetime: 1 });
    } catch(e){
        console.log(e)
    }
   }

}

module.exports = orderService;