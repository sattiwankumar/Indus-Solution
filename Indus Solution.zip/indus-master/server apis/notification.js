const cron = require('node-cron');
const admin = require('firebase-admin');
const orderService = require('./services/order.service');
const UserService = require('./services/user.service');

var serviceAccount = require("./ss.json");
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

async function checkAndSendNotifications() {
  const users = await UserService.getalluser();

  for (const user of users) {
    const orders = await orderService.getorderbynum(user.number);

    if (orders && orders.length > 0) {
      const o = orders[0];
      const givenDate = new Date(o.datetime);
      const currentDate = new Date();
      const timeDifference = givenDate - currentDate;
      const twoDaysInMillis = 2 * 24 * 60 * 60 * 1000;

      if (timeDifference > twoDaysInMillis) {
        const message = {
          token: user.deviceid,
          notification: {
            title: 'Petrol Reminder',
            body: 'Book petrol now Petrol is ending'
          }
        };

        await admin.messaging().send(message)
          .then(response => {
            console.log('Successfully sent notification');
          })
          .catch(error => {
            console.log('Error sending notification:', error);
          });
      }
    }
  }
}


cron.schedule('*/1 * * * *', () => {
  checkAndSendNotifications();
});
