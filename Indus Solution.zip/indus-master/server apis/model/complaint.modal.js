const mongoose = require('mongoose');
const db = require('../config/db');

const { Schema } = mongoose;

const complaintSchema = new Schema({
    title:{
        type:String,
    },
    ans:{
        type:String,
    },
    time:{
        type:String,
    },
    addedby:{
        type:String,
    },
});

const complaintModel = db.model('complaint',complaintSchema);
module.exports = complaintModel;