const mongoose = require('mongoose');
const db = require('../config/db');

const { Schema } = mongoose;

const mechanicsSchema = new Schema({
    name:{
        type:String,
    },
    number:{
        type:String,
    },
    cnic:{
        type:String,
    },
    address:{
        type:String,
    },
    type:{
        type:String,
    },
    profile:{
        type:String,
    },
    cnicf:{
        type:String,
    },
    cnicb:{
        type:String,
    },
    status:{
        type:String,
    },
});

const mechanicsModel = db.model('mechanics',mechanicsSchema);
module.exports = mechanicsModel;