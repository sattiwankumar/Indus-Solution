const mongoose = require('mongoose');
const db = require('../config/db');

const { Schema } = mongoose;

const ordersSchema = new Schema({
    number:{
        type:String,
    },
    quantity:{
        type:String,
    },
    des:{
        type:String,
    },
    loc:{
        type:String,
    },
    type:{
        type:String,
    },
    status:{
        type:String,
    },
    mechanicsid:{
        type:String,
    },
    datetime:{
        type:String,
    },
});

const orderModel = db.model('order',ordersSchema);
module.exports = orderModel;