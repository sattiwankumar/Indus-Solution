const mongoose = require('mongoose');
const db = require('../config/db');

const { Schema } = mongoose;

const notificationSchema = new Schema({
    title:{
        type:String,
    },
    ans:{
        type:String,
    },
    url:{
        type:String,
    },
    time:{
        type:String,
    },
});

const notificationModel = db.model('notification',notificationSchema);
module.exports = notificationModel;