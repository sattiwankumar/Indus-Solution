const mongoose = require('mongoose');
const db = require('../config/db');

const { Schema } = mongoose;

const adminSchema = new Schema({
    num:{
        type:String,
    },
    did:{
        type:String,
    },
});

const adminrModel = db.model('admin',adminSchema);
module.exports = adminrModel;