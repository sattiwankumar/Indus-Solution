package com.example.indus

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
